EDRMS MOTION-GRAPHICS STARTER KIT
=================================
A clean, realistic explainer style (no Papel Tales branding): full-frame scenes, smooth gradients,
soft shadows, real-looking documents, folders, laptop, archive shelves, dashboards. No intro card,
no chapter labels, no headers, no burned-in subtitles. Narration by ElevenLabs.

Contents
  example/edrms-motion.html   the finished story page (8 scenes, 18 lines). Open in a browser to inspect.
  example/edrms-script.txt    script, beat map and shot list
  scripts/tts_el.py           ElevenLabs narration -> n_s_l.wav + durs.json + words.json (word timings)
  scripts/audio2.py           timeline starting at 0.6 s, soft low pad (no vinyl crackle), 2 s tail
  scripts/render720.js        clean full-frame renderer, 1280x720 (no frame, labels, subtitles, grain)
  scripts/render1440-beats.js same, 2560x1440 for final delivery
  scripts/render-par.sh / render-par-1440.sh   4-worker split render
  scripts/lines.js, beats.js  pull narration lines out of the page; word-timed beats
  paper-style-alternative/edrms.html   the same story in Papel Tales paper style

How a scene works
  Each entry in S = {chap, lines:[...], draw(t, li)}. chap is internal only (never drawn).
  draw() paints the whole frame for line li. Use since('word') / RW('word') to time elements to words,
  K(li,from,word) for elements that arrive and stay, V(li,from,word,until) for ones that fade out later.
  Helpers: bgRoom, light, card, sheet (paper with lines/sign/seal/lock/label), fileIcon, folder,
  windowUI, laptop, person, shelves, hourglass, chip, txt (Inter font).
  Rules kept from the Papel Tales recipe: elements arrive early and stay at least 2.5 s, nothing pops
  in during the last 1.5 s of a line, same place = same frame, at most 1-2 slow zooms.

Steps
  1. Write lines + draw() in a copy of edrms-motion.html.
  2. node scripts/lines.js page.html            -> lines.json
  3. python3 scripts/tts_el.py eleven_v4         (voice id at the top of the file; Matilda by default)
  4. python3 scripts/audio2.py                   -> timeline.json + mix.wav
  5. node scripts/render720.js page.html "5,12,20" x.mp4   preview frames p5.jpg ...
  6. sh scripts/render-par.sh page.html out-720p.mp4 4      (or render-par-1440.sh for 1440p)

ElevenLabs setup (once)
  ElevenLabs > Developers > API Keys > Create key. Restrict it: Text to Speech Access, Voices Read,
  Models Access, Forced Alignment Access, Pronunciation Dictionaries Write, User Access; all else none.
  Claude environment > Edit: Allowed domains + api.elevenlabs.io; Network secrets > Add secret:
  Bearer type, website api.elevenlabs.io, header name xi-api-key, empty prefix, value = key.
  Free plan: 10,000 characters a month, no commercial use. Starter plan for anything published.
  Write acronyms for speech as letters (EDRMS -> E.D.R.M.S.); tts_el.py already does this one.

Content note
  The example is deliberately generic (no organisation names, real figures or tenant details) so it can
  be shared publicly. For an internal ADB version, add the real setup (AvePoint on SharePoint/M365,
  declaration, Utilization Report dashboards) and keep it inside the organisation.
Requirements: node + playwright + simplex-noise (../lib/node_modules), ffmpeg, python3 numpy soundfile.
