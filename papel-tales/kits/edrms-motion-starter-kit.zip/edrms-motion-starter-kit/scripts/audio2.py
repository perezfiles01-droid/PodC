import json,numpy as np,soundfile as sf
D=json.load(open('durs.json'));SR=24000;tl=[];t=0.6;prev=-1
for si,li,d in D:
  if si!=prev and prev!=-1: t+=0.9
  tl.append([si,li,t,t+d]);t+=d+0.6;prev=si
T=t+2.0;json.dump({'tl':tl,'T':T},open('timeline.json','w'))
n=np.zeros(int(T*SR))
for si,li,a,b in tl:
  x,_=sf.read(f'n_{si}_{li}.wav');i=int(a*SR);n[i:i+len(x)]+=x
k=np.arange(len(n))/SR;m=np.zeros_like(n)
for f,amp in [(110,.5),(164.8,.35),(220,.3),(277.2,.2)]: m+=amp*np.sin(2*np.pi*f*k)*(0.6+0.4*np.sin(2*np.pi*k/8+f))
m*=0.012;fade=np.minimum(1,np.minimum(k/2,(T-k)/2));m*=fade
out=n*0.95+m;out/=max(1,np.abs(out).max()/0.95);sf.write('mix.wav',out,SR);print(T)
