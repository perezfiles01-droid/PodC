import json,base64,subprocess,urllib.request,re,sys
V='XrExE9yKIg1WjnnlVkGX';L=json.load(open('lines.json'));res=[];WORDS={}
def call(text,model):
  body=json.dumps({'text':text,'model_id':model,'voice_settings':{'stability':0.5,'similarity_boost':0.75}}).encode()
  r=urllib.request.Request(f'https://api.elevenlabs.io/v1/text-to-speech/{V}/with-timestamps?output_format=mp3_44100_128',data=body,headers={'Content-Type':'application/json'})
  return json.load(urllib.request.urlopen(r,timeout=120))
for si,s in enumerate(L):
  for li,t in enumerate(s['lines']):
    sp=t.replace('EDRMS','E.D.R.M.S.')
    try: j=call(sp,sys.argv[1])
    except Exception as e: print('ERR',e.read()[:300] if hasattr(e,'read') else e);raise
    open('tmp.mp3','wb').write(base64.b64decode(j['audio_base64']))
    subprocess.run(['ffmpeg','-v','error','-y','-i','tmp.mp3','-ar','24000','-ac','1',f'n_{si}_{li}.wav'],check=True)
    a=j['alignment'];chars,st=a['characters'],a['character_start_times_seconds'];dur=a['character_end_times_seconds'][-1]
    ws=[];cur='';t0=None
    for ch,ts in zip(chars,st):
      if ch.isspace():
        if cur: ws.append([re.sub(r"[^\w'’-]",'',cur).lower(),round(t0,2)]);cur=''
      else:
        if not cur:t0=ts
        cur+=ch
    if cur: ws.append([re.sub(r"[^\w'’-]",'',cur).lower(),round(t0,2)])
    WORDS.setdefault(si,{})[li]=ws;res.append([si,li,dur+0.15]);print(si,li,round(dur,1))
json.dump(res,open('durs.json','w'));json.dump(WORDS,open('words.json','w'))
