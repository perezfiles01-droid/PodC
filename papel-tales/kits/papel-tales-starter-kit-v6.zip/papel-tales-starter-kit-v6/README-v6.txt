PAPEL TALES STARTER KIT v6  (adds to v5; read README.txt first, then the instructions file, UPDATES v6-v22)

New in v6
  examples/v6/            The Voice, SB19, BINI and EDRMS (paper) story pages + shared head.html/body.js
  scripts/v6/render720.js  fast 720p preview renderer (with the offscreen-canvas fix)
  scripts/v6/render-par.sh 4-worker split render (720p); render-par-1440.sh for YouTube quality
  scripts/v6/tts_el.py     ElevenLabs narration with exact word timings (optional)
  scripts/v6/tts4.py, heteronyms.py, fil.json   latest pronunciation guard and IPA list
  scripts/v6/thumb2.js     thumbnail maker used for SB19/BINI (edit the 'kind' branch per story)

Build order (one story)
  1. cat examples/v6/head.html examples/v6/body.js <story>/scenes.js > story.html  (set const EP in head)
  2. node lines.js story.html
  3. python3 tts4.py (Kokoro, strict check)   or   python3 tts_el.py eleven_v4 (ElevenLabs)
  4. python3 audio.py
  5. preview:  node render720.js story.html "t1,t2,..." x.mp4   (writes p<t>.jpg)
  6. quick:    sh render-par.sh story.html story-720p.mp4 4
     YouTube:  sh render-par-1440.sh story.html story-raw.mp4 4, then two-pass compress to ~95 MB
Paths inside the scripts expect ../voice (Kokoro model) and ../lib/node_modules (playwright,
simplex-noise). Install: pip install kokoro-onnx soundfile cmudict; npm i playwright simplex-noise.
Large outputs (mp4, wav) are not included; the published videos are linked in the instructions.
