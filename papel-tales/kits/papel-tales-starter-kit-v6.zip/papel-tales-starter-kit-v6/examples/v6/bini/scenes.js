
/* ================= BINI: a paper garden that blooms (petals, seed packets, pressed-flower cards) ================= */
function K(li,from,word,dur=.9){if(li<from)return 0;if(li>from)return 1;return word?RW(word,dur):EASE(clamp01(lt()/dur))}
function walkX(li,from,x0,x1,dur=2.2,word=null){if(li<from)return [x0,false];if(li>from)return [x1,false];const d=word?since(word):lt();if(d<0)return [x0,false];const p=clamp01(d/dur);return [x0+(x1-x0)*SM(p),p<1]}
const GIRLS=[['AIAH','#f28fb1','#2a1d14'],['COLET','#e63946','#111'],['MALOI','#f4c430','#3a2214'],['GWEN','#2bb3a3','#1a1a1a'],['STACEY','#b9a3e3','#4a2a1a'],['MIKHA','#3a6fd8','#111'],['JHOANNA','#e8743b','#2a1d14'],['SHEENA','#7cc242','#3a2214']];
const XS=[110,260,410,560,720,870,1020,1170];
// new design: paper-flower girls, petal skirts, long cut-paper hair
function girl(x,y,s,t,i,o={}){const [,col,hc]=GIRLS[i];const mv=o.dance?Math.sin(t*6+i):0,bob=o.dance?Math.abs(Math.sin(t*6+i))*10*s:0;c.save();c.translate(x,y-bob);
 [[-9,mv*.4],[9,-mv*.4]].forEach(([dx,a])=>{c.save();c.translate(dx*s,-64*s);c.rotate(a);stk('#c99a72',()=>rr(-6*s,0,12*s,64*s,6*s),1.8,0);stk(col,()=>ell(4*s,64*s,11*s,6*s),1.4,0);c.restore()});
 for(let k=0;k<5;k++){c.save();c.translate(0,-70*s);c.rotate(-.7+k*.35+mv*.05);stk(col,()=>ell(0,0,16*s,30*s),1.6,0);c.restore()}
 stk('#fffdf4',()=>rr(-22*s,-140*s,44*s,72*s,14*s),2.2,5);fill(col,()=>c.rect(-22*s,-110*s,44*s,8*s),0);
 const arm=f=>{c.save();c.translate(f*22*s,-134*s);c.rotate(o.cheer?f*-2.6+Math.sin(t*8)*.2*f:o.dance?f*(.4+Math.sin(t*6+i+f)*1.1):f*.25);stk('#c99a72',()=>rr(-6*s,0,12*s,54*s,6*s),1.8,0);c.restore()};arm(-1);arm(1);
 const hy=-176*s;stk(hc,()=>{rr(-36*s,hy-18*s,18*s,74*s,9*s);rr(18*s,hy-18*s,18*s,74*s,9*s)},2,4);stk('#d9a879',()=>circ(0,hy,27*s),2.2,0);stk(hc,()=>{c.arc(0,hy-4*s,29*s,Math.PI*1.05,Math.PI*1.95);c.closePath()},1.6,0);
 fill(INK,()=>{ell(-10*s,hy+2*s,3.4*s,4.4*s);ell(10*s,hy+2*s,3.4*s,4.4*s)},0);fill('rgba(240,90,110,.4)',()=>{circ(-17*s,hy+11*s,5*s);circ(17*s,hy+11*s,5*s)},0);
 c.save();c.strokeStyle=INK;c.lineWidth=2.4*s;c.beginPath();c.arc(0,hy+9*s,8*s,.3,Math.PI-.3);c.stroke();c.restore();
 stk(col,()=>{for(let k=0;k<5;k++){const a=k/5*Math.PI*2;circ(22*s+Math.cos(a)*6*s,hy-22*s+Math.sin(a)*6*s,5*s)}},1.2,0);
 if(o.sweat){const p=(t*.9+i*.2)%1;fill('#8fd3ff',()=>ell(26*s,hy-6*s+p*28*s,3.5*s,5.5*s),0)}
 c.restore()}
// running gag: a stubborn bud in a pot that refuses to open
function bud(x,y,s,t,open=0,o={}){stk('#c4663a',()=>{c.moveTo(x-40*s,y-60*s);c.lineTo(x+40*s,y-60*s);c.lineTo(x+30*s,y);c.lineTo(x-30*s,y);c.closePath()},2,5);
 line([[x,y-60*s],[x+Math.sin(t*1.5)*6*s,y-170*s]],'#3f8a3a',6*s);stk('#5aa02c',()=>ell(x-18*s,y-110*s,18*s,8*s,-.5),1.4,0);
 const hx=x+Math.sin(t*1.5)*6*s,hy=y-180*s;
 if(open>0){for(let k=0;k<8;k++){const a=k/8*Math.PI*2+t*.2;c.save();c.translate(hx,hy);c.rotate(a);stk(['#f28fb1','#ffd1e0'][k%2],()=>ell(0,-26*s*open,12*s,24*s*open),1.4,0);c.restore()}stk('#f4c430',()=>circ(hx,hy,12*s),1.4,0)}
 else{stk('#7cc242',()=>ell(hx,hy,16*s,24*s),1.8,4);fill('#f28fb1',()=>ell(hx,hy-14*s,7*s,10*s),0)}
 // face on the bud
 const fy=open>0?hy:hy+4*s;fill(INK,()=>{circ(hx-5*s,fy,2.4*s);circ(hx+5*s,fy,2.4*s)},0);
 c.save();c.strokeStyle=INK;c.lineWidth=1.8*s;c.beginPath();if(o.pout)c.moveTo(hx-4*s,fy+8*s),c.lineTo(hx+4*s,fy+8*s);else c.arc(hx,fy+5*s,4*s,.3,Math.PI-.3);c.stroke();c.restore();
 if(o.sweat)fill('#8fd3ff',()=>ell(hx+16*s,hy-8*s,3*s,5*s),0)}
function garden(t,warm=false){linedSky(warm?'#ffd9a8':'#cfe8f5',warm?'#fff1dc':'#f5fbf2',0,440);
 // greenhouse frame (far)
 c.save();c.strokeStyle='rgba(255,255,255,.7)';c.lineWidth=6;for(let i=0;i<9;i++){c.beginPath();c.moveTo(-60+i*175,440);c.lineTo(-60+i*175,60);c.stroke()}c.beginPath();c.moveTo(-160,60);c.lineTo(W+160,60);c.stroke();c.restore();
 for(let i=0;i<14;i++){const x=hr(i)*W,yy=430;line([[x,yy],[x,yy-60-hr(i*3)*60]],'#3f8a3a',4);stk(['#f28fb1','#f4c430','#b9a3e3','#e63946'][i%4],()=>circ(x,yy-70-hr(i*3)*60,12),1.4,0)}
 fill('#8a5a3a',()=>c.rect(-160,440,W+320,H),5);patt('#7a4e30',()=>c.rect(-160,470,W+320,H),2,'rgba(0,0,0,.08)',0)}
function bootcamp(t){bg('#e8ecf2');fill('#c8ced8',()=>c.rect(-160,-80,W+320,300),0);for(let i=0;i<10;i++)stk('#fffdf4',()=>rr(-80+i*150,40,110,70,6),1.4,3);
 wood('#c49a6a',()=>c.rect(-160,420,W+320,H),5,6);stk('#1b1f3b',()=>rr(360,140,560,90,10),2.4,8);hand('STAR HUNT ACADEMY',640,200,44,'#fff6dc');
 line([[-160,560],[W+160,560]],'rgba(255,255,255,.5)',3)}
function gradStage(t){bg('#1b1f3b');rays(640,-40,'255,220,240',7,900,.14,t);stk('#2a2e4a',()=>rr(-160,470,W+320,300,0),2,0);
 bunting(50,t,['#f28fb1','#fffdf4','#b9a3e3'])}
function runway(t){bg('#f6e8ee');for(let i=0;i<9;i++)stk(i%2?'#f28fb1':'#ffd1e0',()=>rr(-120+i*160,-40,150,500,0),0,0);
 stk('#fffdf4',()=>{c.moveTo(520,470);c.lineTo(760,470);c.lineTo(980,H+60);c.lineTo(300,H+60);c.closePath()},2.4,6);
 // screens of fans watching from home
 for(let i=0;i<4;i++){const x=i<2?120+i*170:900+(i-2)*170;c.save();c.translate(x,240);stk('#2a2e3a',()=>rr(-70,-50,140,100,10),2,4);fill('#cfe8f5',()=>c.rect(-60,-40,120,80),0);fill('#d9a879',()=>circ(0,-4,16),0);fill(INK,()=>{circ(-5,-6,2);circ(5,-6,2)},0);heartS(30,-20,.6,'#e63946');c.restore()}}
function beach(t){linedSky('#7fd3f0','#fff1c4',0,420);fill('#ffd27a',()=>circ(1040,140,70),0);water(380,t,'#2aa0d8');fill('#f2d6a0',()=>c.rect(-160,470,W+320,H),4);
 palm(80,520,1,t,'#2f7a46');palm(1220,520,1,t+1,'#2f7a46')}
function desertStage(t){linedSky('#ffb35c','#ffe2a8',0,460);mountains(420,'#d99a5a','#c8854a',3,120);
 // ferris wheel (far)
 c.save();c.translate(1080,250);c.strokeStyle='#5a3a6a';c.lineWidth=4;c.beginPath();circ(0,0,120);c.stroke();for(let i=0;i<10;i++){const a=i/10*Math.PI*2+t*.15;line([[0,0],[Math.cos(a)*120,Math.sin(a)*120]],'#5a3a6a',2);stk(['#e63946','#f4c430','#2bb3a3'][i%3],()=>circ(Math.cos(a)*120,Math.sin(a)*120,12),1.2,0)}c.restore();line([[1080,250],[1020,430]],'#5a3a6a',6);line([[1080,250],[1140,430]],'#5a3a6a',6);
 fill('#e2c08a',()=>c.rect(-160,430,W+320,H),4);stk('#2a2e4a',()=>rr(60,380,860,60,6),2.4,6);
 palm(-30,700,1.2,t,'#2a3a22')}

const S=[
{chap:'A tiny bud',lines:[
 'Every flower starts as a tiny bud. Some take a long time to open.',
 'This little one? Very, very long.'],
 draw(t,li){PL(t,.3,()=>garden(t));
  PL(t,1,()=>{bud(640,640,1.6,t,0,{pout:li===1&&since('very')>=0,sweat:li===1});
   withA(K(li,0,null,1),()=>{c.save();c.translate(260,560);c.rotate(-.06);stk('#fffdf4',()=>rr(-90,-60,180,120,4),2,6);hand('seed packet',0,-20,24,'#5aa02c');hand('8 seeds',0,24,34,'#e63946');c.restore()})});}},

{chap:'Star Hunt Academy',lines:[
 'In twenty eighteen, ABS-CBN\'s Star Hunt Academy began training a group of young hopefuls.',
 'Filipino and Korean coaches drilled them in singing and dancing, again and again.'],
 draw(t,li){PL(t,.3,()=>bootcamp(t));
  PL(t,1,()=>{withA(vis(li,0,'eighteen',1),()=>stamp('2018',1120,330,1,'#1b1f3b'));
   XS.forEach((x,i)=>girl(x,640,.85,t,i,{dance:li===1,sweat:li===1}));
   if(li===1){silP(640,700,.0001,t)}
   bud(1220,710,.6,t,0,{pout:true})});}},

{chap:'Graduation, 2020',lines:[
 'In October twenty twenty, eight trainees graduated: Aiah, Colet, Maloi, Gwen, Stacey, Mikha, Jhoanna, and Sheena.',
 'Their name, BINI, comes from binibini, the Filipino word for a young lady.',
 'Their first song was a fresh take on the classic Da Coconut Nut.'],
 draw(t,li){PL(t,.3,()=>gradStage(t));
  PL(t,1,()=>{withA(vis(li,0,'october',2),()=>stamp('2020',1120,150,1,'#f28fb1'));
   XS.forEach((x,i)=>{girl(x,600,.85,t,i,{dance:li===2,cheer:li===0&&since(GIRLS[i][0].toLowerCase())>=0&&since(GIRLS[i][0].toLowerCase())<2});tag(x,370,GIRLS[i][0],vis(li,0,GIRLS[i][0].toLowerCase(),0),'#fffdf4',INK,18)});
   if(li===1)withA(K(li,1,'binibini'),()=>{c.save();c.translate(640,180);stk('#fffdf4',()=>rr(-260,-60,520,120,8),2.4,8);hand('BINI ← binibini',0,-6,46,'#e63946');hand('young lady',0,40,28,INK);c.restore()});
   if(li===2)withA(K(li,2,null),()=>{for(let k=0;k<3;k++){const p=(t*.4+k/3)%1;c.save();c.translate(200+k*440,120+p*380);c.rotate(p*6);stk('#7a4e30',()=>circ(0,0,28),1.8,0);fill('#e8d9b8',()=>circ(0,0,10),0);c.restore()}hand('Da Coconut Nut',640,150,44,'#fff6dc')})});}},

{chap:'Debut, 2021',lines:[
 'On June eleventh, twenty twenty-one, they officially debuted with Born to Win.',
 'It was the pandemic, so their first crowds were mostly on screens.'],
 draw(t,li){PL(t,.3,()=>runway(t));
  PL(t,1,()=>{withA(vis(li,0,'june',1),()=>stamp('2021',640,110,1,'#e63946'));tag(640,190,'BORN TO WIN',vis(li,0,'born',1),'#fffdf4','#e63946',30);
   [520,560,600,640,680,720,760,800].forEach((x,i)=>girl(x,560+Math.abs(i-3.5)*10,.6,t,i,{dance:true}))});}},

{chap:'Pantropiko',lines:[
 'Then, in twenty twenty-three, came Pantropiko, a sunny summer song with a dance anyone could copy.',
 'Soon it seemed to be everywhere: on phones, at parties, at school programs.',
 'BINI became known as the Nation\'s Girl Group, and their fans, the Blooms, kept growing.'],
 draw(t,li){PL(t,.3,()=>beach(t));
  PL(t,1,()=>{withA(vis(li,0,'twenty',2),()=>stamp('2023',200,130,1,'#e8743b'));tag(640,120,'PANTROPIKO',vis(li,0,'pantropiko',2),'#ffd27a',INK,36);
   XS.forEach((x,i)=>girl(x,650,.8,t,i,{dance:true}));
   if(li>=1){const n=li===1?Math.floor(clamp01(Math.max(0,since('soon'))/3)*10):10;for(let k=0;k<n;k++){c.save();c.translate(70+k*125,290+Math.sin(t*2+k)*6);stk('#2a2e3a',()=>rr(-26,-44,52,88,8),1.6,3);fill('#ffe9b0',()=>c.rect(-20,-36,40,72),0);for(let j=0;j<3;j++)fill(GIRLS[(k+j)%8][1],()=>circ(-10+j*10,0+Math.sin(t*6+j)*4,4),0);c.restore()}}
   if(li===2){const k=K(li,2,'blooms',1.4);for(let j=0;j<40;j++){const p=(t*.12+hr(j))%1;fill(['#f28fb1','#ffd1e0','#fffdf4'][j%3],()=>ell(hr(j*3)*W,p*H*k,7,4,p*6),0)}tag(640,210,"NATION'S GIRL GROUP",vis(li,2,'nation',2),'#fffdf4','#e63946',30)}});}},

{chap:'Coachella, 2026',lines:[
 'In April twenty twenty-six, they even performed at Coachella in California.'],
 draw(t,li){PL(t,.3,()=>desertStage(t));
  PL(t,1,()=>{withA(K(li,0,'april'),()=>stamp('2026',200,130,1,'#5a3a6a'));tag(490,240,'COACHELLA',K(li,0,'coachella'),'#fffdf4','#5a3a6a',32);
   [150,250,350,450,550,650,750,850].forEach((x,i)=>girl(x,380,.65,t,i,{dance:true}));
   for(let j=0;j<30;j++){const x=-40+j*46,y=690-Math.abs(Math.sin(t*4+j))*10;fill('#3a2a3a',()=>circ(x,y-20,14),0);if(j%3===0)line([[x+8,y-30],[x+18,y-60]],'#3a2a3a',5)}});}},

{chap:'In full bloom',lines:[
 'So how did BINI bloom? Years of practice, eight friends, and a lot of patience.',
 'And the little bud? It finally opened too.'],
 draw(t,li){PL(t,.3,()=>garden(t,true));
  PL(t,1,()=>{XS.forEach((x,i)=>girl(x,600,.75,t,i,{cheer:li===1&&since('opened')>=0,dance:li===0}));
   const op=li===1?RW('opened',1.4):0;bud(640,700,1,t,op,{});
   if(li===1&&since('opened')>=0){const a=SM(clamp01((since('opened')-.8)/1.6));c.save();c.globalAlpha=a;titleCard(t);c.restore()}});}}
];

const SHOTS={'6.1':['push',1.25,640,520]};
S.forEach((sc,si)=>{const base=sc.draw;sc.draw=function(t,li){const key=si+'.'+li,sp=SHOTS[key];
  const isCur=window.CL&&window.CL.s===si,savedCL=window.CL;if(window.CL&&!isCur)window.CL={s:si,l:li,lt:99};const L=isCur?lt():99;
  let z=1,cx=W/2,cy=H/2;if(sp){cx=sp[2];cy=sp[3];z=1+(sp[1]-1)*SM(clamp01(L/1.4))}
  c.save();if(z!==1){c.translate(W/2,H/2);c.scale(z,z);c.translate(-cx,-cy)}
  base.call(this,t,li);c.restore();
  if(si>=1&&li===0&&t<7.6)onAir(sc.chap,clamp01((t-4.2)/.6)*clamp01((7.6-t)/.7),t);
  window.CL=savedCL}});
window.since=function(word){const k=window.CL;if(!k)return 99;const Lw=(WORDS[k.s]||{})[k.l]||[];const w=word.toLowerCase();const hit=Lw.find(x=>x[0]===w||x[0].startsWith(w));if(!hit)return -1;
 let g=Math.floor(hit[1]/1.8)*1.8;const rw=(window.TL||[]).find(x=>x[0]===k.s&&x[1]===k.l);if(rw)g=Math.min(g,Math.max(0,(rw[3]-rw[2])-2.5));const d=k.lt-g;return d>=0?d:-1};
window.FONTS=Promise.all(["700 40px Caveat","900 40px Fredoka","700 40px Fredoka","700 25px Nunito"].map(f=>document.fonts.load(f)));
</script>
