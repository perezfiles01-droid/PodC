
/* ================= THE VOICE: paper TV studio seen from backstage ================= */
const RED='#d7263d',RED2='#9e1a2c',NAVY='#1b1f3b',INK='#15131f',FOIL='#c9ccd6',TAPE='#f2d03b';
const EASE=x=>x<=0?0:x>=1?1:1-Math.pow(1-x,3);
const SM=x=>x<=0?0:x>=1?1:x*x*(3-2*x);
// a line-relative ramp: 0 before the word, eases to 1 over dur
function RW(word,dur=1){const d=since(word);return d<0?0:EASE(clamp01(d/dur))}
function tag(x,y,txt,a=1,col='#fffdf4',ink=INK,size=24){if(a<=0)return;c.save();c.globalAlpha*=a;c.font=`700 ${size}px Fredoka,sans-serif`;const w=c.measureText(txt).width+28;
 c.translate(x,y);c.rotate(-.02);stk(col,()=>rr(-w/2,-size*.9,w,size*1.6,8),2,6);c.fillStyle=ink;c.textAlign='center';c.fillText(txt,0,size*.35);c.restore()}

/* ---- the big red chair. turn: 0 = back to us, 1 = facing us ---- */
function chair(x,y,s,turn,o={}){const k=Math.cos(clamp01(turn)*Math.PI),w=Math.max(.05,Math.abs(k));
 c.save();c.translate(x,y);
 fill('#2a2a33',()=>ell(0,0,70*s,14*s),3);line([[0,-4*s],[0,-60*s]],'#55565f',10*s);
 c.save();c.scale(w,1);
 if(k>0){ // back of the chair
  if(o.hair)stk(o.hair,()=>ell(0,-252*s,30*s,22*s),2,4);
  stk(RED,()=>rr(-95*s,-250*s,190*s,200*s,48*s),2.6,8);
  c.save();c.strokeStyle='rgba(0,0,0,.18)';c.lineWidth=3*s;for(let i=-2;i<=2;i++){c.beginPath();c.moveTo(i*34*s,-232*s);c.lineTo(i*34*s,-72*s);c.stroke()}c.restore();
  fill(RED2,()=>rr(-95*s,-74*s,190*s,22*s,10*s),0);
 }else{ // front: the coach sitting in it
  stk(RED,()=>rr(-95*s,-250*s,190*s,200*s,48*s),2.6,8);fill('#7a1222',()=>rr(-70*s,-226*s,140*s,170*s,36*s),0);
  const ch=o.cheer?Math.sin(o.t*7)*.2:0;
  stk(o.coat||'#2c2c44',()=>{c.moveTo(-50*s,-62*s);c.quadraticCurveTo(-52*s,-150*s,0,-158*s);c.quadraticCurveTo(52*s,-150*s,50*s,-62*s);c.closePath()},2.4,5);
  if(o.cape)stk('#c9a3ff',()=>{c.moveTo(-54*s,-150*s);c.lineTo(-74*s,-62*s);c.lineTo(-40*s,-62*s);c.moveTo(54*s,-150*s);c.lineTo(74*s,-62*s);c.lineTo(40*s,-62*s)},1.6,0);
  stk('#c99a72',()=>circ(0,-188*s,32*s),2.4,5);
  stk(o.hair||'#3a2a1c',()=>{c.arc(0,-192*s,34*s,Math.PI*1.02,Math.PI*1.98);c.closePath()},2,0);
  fill(INK,()=>{circ(-11*s,-188*s,3.4*s);circ(11*s,-188*s,3.4*s)},0);c.save();c.strokeStyle=INK;c.lineWidth=2.6*s;c.beginPath();c.arc(0,-178*s,10*s,.25,Math.PI-.25);c.stroke();c.restore();
  if(o.hat){stk('#b07a45',()=>{ell(0,-218*s,56*s,11*s);c.moveTo(-28*s,-218*s);c.quadraticCurveTo(-30*s,-262*s,0,-252*s);c.quadraticCurveTo(30*s,-262*s,28*s,-218*s)},2,4)}
  [[-1],[1]].forEach(([f])=>{c.save();c.translate(f*44*s,-136*s);c.rotate(f*(o.cheer?-2.5+ch:.5));stk(o.coat||'#2c2c44',()=>rr(-8*s,0,16*s,52*s,8*s),2,0);stk('#c99a72',()=>circ(0,56*s,9*s),1.6,0);c.restore()});
 }
 c.restore();
 // armrest button (never mirrored, stays readable)
 if(o.button!==false){const bx=(k>0?1:-1)*104*s*w,by=-96*s,pr=o.press||0;stk('#3a3a44',()=>rr(bx-16*s,by,32*s,40*s,6*s),2,0);stk(o.lit?'#ff5a6e':RED,()=>ell(bx,by-2*s+pr*6*s,20*s,9*s),2,3);if(o.lit)glow(bx,by,60*s,'255,80,100',.4)}
 c.restore()}
// rotation helper: chair turns during [a..a+1.1] s of the clock value d
const turnK=d=>d<0?0:SM(clamp01(d/1.1));

/* ---- singers: tall paper beans, huge mouths, eyes close when they sing ---- */
function bean(x,y,s,t,o={}){const col=o.col||'#f29e4c',sing=o.sing||0,wob=o.wobble?Math.sin(t*22)*.12:0,step=o.walk?Math.sin(t*8):0;
 c.save();c.translate(x,y-(o.walk?Math.abs(step)*6*s:0));if(o.face===-1)c.scale(-1,1);
 [[-14,wob+step*.4],[14,-wob-step*.4]].forEach(([dx,a])=>{c.save();c.translate(dx*s,-40*s);c.rotate(a);stk('#2b2b3a',()=>rr(-6*s,0,12*s,42*s,6*s),2,0);stk('#2b2b3a',()=>ell(4*s,42*s,12*s,6*s),2,0);c.restore()});
 stk(col,()=>ell(0,-120*s,46*s,88*s),2.6,8);
 fill('rgba(255,255,255,.25)',()=>ell(-16*s,-160*s,10*s,26*s),0);
 const ey=-168*s;if(sing>0.2){c.save();c.strokeStyle=INK;c.lineWidth=3*s;[-14,14].forEach(dx=>{c.beginPath();c.arc(dx*s,ey,6*s,Math.PI*1.15,Math.PI*1.85);c.stroke()});c.restore()}
 else fill(INK,()=>{circ(-14*s,ey,4.5*s);circ(14*s,ey,4.5*s)},0);
 if(o.blush)fill('rgba(240,90,110,.45)',()=>{ell(-26*s,ey+16*s,8*s,5*s);ell(26*s,ey+16*s,8*s,5*s)},0);
 const mo=sing>0?(10+18*sing*(0.6+0.4*Math.abs(Math.sin(t*7))))*s:4*s;
 stk('#5a1424',()=>ell(0,-128*s,22*s,mo),2.2,0);if(mo>12*s)fill('#ff8fa0',()=>ell(0,-128*s+mo*.5,12*s,mo*.35),0);
 if(o.smile&&sing<=0){fill(col,()=>ell(0,-128*s,24*s,mo+2*s),0);c.save();c.strokeStyle=INK;c.lineWidth=3*s;c.beginPath();c.arc(0,-136*s,16*s,.3,Math.PI-.3);c.stroke();c.restore()}
 // arm holding the microphone up near the mouth
 c.save();c.translate(30*s,-108*s);c.rotate(-.9);stk(col,()=>rr(-7*s,0,14*s,44*s,7*s),2,0);c.restore();
 stk('#2b2b3a',()=>rr(40*s,-140*s,8*s,34*s,3*s),1.6,0);stk(FOIL,()=>circ(44*s,-146*s,10*s),1.6,0);
 c.restore()}
// a paper waveform ribbon carrying the voice from a to b, drawn up to fraction f
function ribbon(x0,y0,x1,y1,t,f=1,col='#fff3c4'){if(f<=0)return;const n=60,m=Math.max(2,Math.floor(n*clamp01(f)));c.save();sh(true,3);c.lineCap='round';
 for(const [lw,cc] of [[16,'rgba(255,255,255,.9)'],[9,col]]){c.strokeStyle=cc;c.lineWidth=lw;c.beginPath();for(let i=0;i<=m;i++){const p=i/n,x=x0+(x1-x0)*p,y=y0+(y1-y0)*p-Math.sin(p*Math.PI)*80+Math.sin(p*22-t*6)*14*Math.sin(p*Math.PI);i?c.lineTo(x,y):c.moveTo(x,y)}c.stroke()}c.restore()}
function notes(x,y,t,n=3,col='#fffdf4'){for(let i=0;i<n;i++){const p=(t*.45+i/n)%1;c.save();c.globalAlpha*=Math.sin(p*Math.PI);hand('♪',x+Math.sin(p*6+i)*18+i*14,y-p*70,30,col);c.restore()}}

/* ---- PIP, the paper pigeon (running gag) ---- */
function pip(x,y,s,t,o={}){c.save();c.translate(x,y);if(o.face===-1)c.scale(-1,1);if(o.rot)c.rotate(o.rot);const bob=o.sing?Math.sin(t*9)*3*s:Math.sin(t*3)*1.5*s;
 [[-8],[8]].forEach(([dx])=>line([[dx*s,-6*s],[dx*s,4*s],[dx*s+6*s,6*s]],'#e8743b',3*s));
 stk('#9aa0b2',()=>ell(0,-26*s,30*s,22*s),2,5);stk('#7c8296',()=>{c.moveTo(-6*s,-30*s);c.quadraticCurveTo(-34*s,-24*s,-40*s,-12*s);c.quadraticCurveTo(-18*s,-14*s,-2*s,-18*s)},1.6,0);
 if(o.jacket)stk('#e63946',()=>{c.moveTo(-22*s,-40*s);c.lineTo(22*s,-40*s);c.lineTo(26*s,-14*s);c.lineTo(-26*s,-14*s);c.closePath()},1.6,0);
 const hy=-56*s+bob;fill('#6fbf9a',()=>ell(10*s,hy+16*s,16*s,8*s),0);fill('#9b7fd0',()=>ell(10*s,hy+20*s,14*s,5*s),0);
 stk('#a7adbf',()=>circ(12*s,hy,17*s),2,4);
 const op=o.sing?Math.abs(Math.sin(t*9))*7*s:0;stk('#f4a340',()=>{c.moveTo(26*s,hy-2*s-op*.4);c.lineTo(40*s,hy+2*s);c.lineTo(26*s,hy+4*s+op)},1.4,0);
 if(o.sing){c.save();c.strokeStyle=INK;c.lineWidth=2.4*s;c.beginPath();c.arc(14*s,hy-4*s,4*s,Math.PI*1.1,Math.PI*1.9);c.stroke();c.restore()}
 else{fill('#fff',()=>circ(15*s,hy-4*s,6*s),0);fill(INK,()=>circ(17*s,hy-4*s,3.2*s),0)}
 if(o.tears){for(let i=0;i<2;i++){const p=(t*1.4+i*.5)%1;fill('#8fd3ff',()=>ell(10*s-p*16*s,hy+p*24*s,3*s,5*s),0)}}
 if(o.sweat)fill('#8fd3ff',()=>ell(-2*s,hy-16*s,4*s,6*s),0);
 c.restore();if(o.sing)notes(x+30*s,y-80*s,t,2)}
function tinyChair(x,y,s,turn=0){chair(x,y,s,turn,{button:false})}

/* ---- silhouette portraits for real people (no caricature): dark paper + one colour pop ---- */
function silP(x,y,s,t,o={}){const st=o.walk?Math.sin(t*7):0;c.save();c.translate(x,y);if(o.face===-1)c.scale(-1,1);const D=o.dark||'#1e2236';
 [[-12,st*.35],[12,-st*.35]].forEach(([dx,a])=>{c.save();c.translate(dx*s,-80*s);c.rotate(a);fill(D,()=>rr(-9*s,0,18*s,82*s,8*s),2);c.restore()});
 stk(D,()=>{c.moveTo(-38*s,-80*s);c.lineTo(-34*s,-190*s);c.quadraticCurveTo(0,-206*s,34*s,-190*s);c.lineTo(38*s,-80*s);c.closePath()},2,6);
 fill(o.pop||RED,()=>{c.moveTo(-8*s,-196*s);c.lineTo(8*s,-196*s);c.lineTo(4*s,-130*s);c.lineTo(-4*s,-130*s)},0);
 const ra=o.scratch?-2.6+Math.sin(t*6)*.15:o.point?-1.4:o.hold?-1:.15;
 c.save();c.translate(-32*s,-186*s);c.rotate(.15);fill(D,()=>rr(-8*s,0,16*s,80*s,8*s),0);c.restore();
 c.save();c.translate(32*s,-186*s);c.rotate(ra);fill(D,()=>rr(-8*s,0,16*s,80*s,8*s),0);c.restore();
 stk(D,()=>circ(0,-232*s,30*s),2,6);if(o.hair)fill(o.hair,()=>{c.arc(0,-236*s,31*s,Math.PI*1.05,Math.PI*1.95);c.closePath()},0);
 if(o.glasses){c.save();c.strokeStyle='#f6f2e6';c.lineWidth=2.5*s;c.beginPath();circ(-10*s,-232*s,8*s);circ(14*s,-232*s,8*s);c.stroke();c.restore()}
 c.restore()}

/* ---- sets ---- */
function studioWall(t,top,bot,beam='255,240,210'){const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,top);g.addColorStop(1,bot);c.fillStyle=g;c.fillRect(-160,-80,W+320,H+160);
 c.save();c.strokeStyle='rgba(255,255,255,.05)';c.lineWidth=2;for(let x=-160;x<W+160;x+=64){c.beginPath();c.moveTo(x,-80);c.lineTo(x,H+80);c.stroke()}c.restore();
 // lighting truss
 fill('#3a3c48',()=>rr(-160,40,W+320,16,4),3);for(let i=0;i<9;i++){const x=40+i*150;stk('#2b2d38',()=>rr(x-16,52,32,36,6),1.6,0);glow(x,92,40,beam,.35)}}
function floorStage(y,col='#2c2f3d',tape=true){fill(col,()=>c.rect(-160,y,W+320,H-y+160),6);c.save();c.strokeStyle='rgba(255,255,255,.06)';for(let i=0;i<12;i++){c.beginPath();c.moveTo(-160+i*140,y);c.lineTo(-500+i*190,H+80);c.stroke()}c.restore()}
function tapeX(x,y,s=1){line([[x-22*s,y-10*s],[x+22*s,y+10*s]],TAPE,8*s);line([[x+22*s,y-10*s],[x-22*s,y+10*s]],TAPE,8*s)}
function spot(x,y,w,a=.35,col='255,248,220'){c.save();c.globalCompositeOperation='lighter';const g=c.createLinearGradient(x,0,x,y);g.addColorStop(0,`rgba(${col},${a*.2})`);g.addColorStop(1,`rgba(${col},${a})`);c.fillStyle=g;c.beginPath();c.moveTo(x-30,0);c.lineTo(x+30,0);c.lineTo(x+w,y);c.lineTo(x-w,y);c.fill();c.restore();fill(`rgba(${col},${a*.6})`,()=>ell(x,y,w,w*.18),0)}
function risers(y,t,cols=['#3b4a7a','#45558a','#33416e']){for(let r=0;r<3;r++){fill(cols[r],()=>c.rect(-160,y-r*46,W+320,46),2);for(let i=0;i<22;i++){const hx=-120+i*66+(r%2)*33,b=Math.sin(t*2+i+r)*2;fill(['#d8c3a5','#a87b5c','#e7cfa8','#7a5a44'][(i+r)%4],()=>circ(hx,y-r*46-12+b,13),0);fill('rgba(20,20,40,.55)',()=>rr(hx-14,y-r*46-2+b,28,20,6),0)}}}
function delftWall(){bg('#f4f1e8');c.save();for(let y=-80;y<H+80;y+=64)for(let x=-160;x<W+160;x+=64){c.strokeStyle='rgba(40,70,150,.25)';c.lineWidth=1.5;c.strokeRect(x,y,64,64);
 c.fillStyle='rgba(40,70,150,.55)';c.beginPath();const cx=x+32,cy=y+32;for(let i=0;i<4;i++){const a=i*Math.PI/2;c.moveTo(cx,cy);c.quadraticCurveTo(cx+Math.cos(a+.6)*16,cy+Math.sin(a+.6)*16,cx+Math.cos(a)*14,cy+Math.sin(a)*14)}c.fill();c.fillRect(x+2,y+2,6,6);c.fillRect(x+56,y+2,6,6)}c.restore()}
function canalWindow(x,y,w,h,t){c.save();c.beginPath();c.rect(x,y,w,h);c.clip();sky('#bfd9ee','#eef4f8');
 for(let i=0;i<5;i++){const hx=x+i*(w/5),hh=120+(i%2)*40;fill(['#8a3b2a','#4a5a6a','#a8693a','#3d3d4d','#7a2e2e'][i],()=>{c.moveTo(hx,y+h-60);c.lineTo(hx,y+h-60-hh);c.lineTo(hx+w/10,y+h-60-hh-30);c.lineTo(hx+w/5,y+h-60-hh);c.lineTo(hx+w/5,y+h-60)},2);for(let j=0;j<2;j++)fill('#f6f2e6',()=>c.rect(hx+14+j*(w/10-6),y+h-60-hh+30,16,22),0)}
 water(y+h-60,t,'#4f7f9a');
 for(let i=0;i<3;i++){const bx=x+60+i*120+((t*12)%40);c.save();c.strokeStyle=INK;c.lineWidth=3;c.beginPath();circ(bx,y+h-70,13);circ(bx+38,y+h-70,13);c.moveTo(bx,y+h-70);c.lineTo(bx+16,y+h-92);c.lineTo(bx+38,y+h-70);c.stroke();c.restore()}
 c.restore();wood('#6b4425',()=>{c.rect(x-14,y-14,w+28,14);c.rect(x-14,y+h,w+28,14);c.rect(x-14,y,14,h);c.rect(x+w,y,14,h);c.rect(x+w/2-6,y,12,h)},6,3)}
function deskTop(y){wood('#8a5a2e',()=>c.rect(-160,y,W+320,H-y+160),8,7);fill('rgba(0,0,0,.18)',()=>c.rect(-160,y,W+320,10),0)}
function photo(x,y,w,h,k,rot,inner,flip=0){const f=Math.cos(clamp01(flip)*Math.PI);c.save();c.translate(x,y);c.rotate(rot);c.scale(Math.max(.04,Math.abs(f))*k,k);
 if(f>0){stk('#fffdf4',()=>rr(-w/2,-h/2,w,h,4),2,6);c.save();c.beginPath();c.rect(-w/2+8,-h/2+8,w-16,h-30);c.clip();c.fillStyle='#e9e1d0';c.fillRect(-w/2,-h/2,w,h);inner();c.restore()}
 else{stk('#d8cdb4',()=>rr(-w/2,-h/2,w,h,4),2,6);hand('?',0,10,40,'rgba(60,40,20,.4)')}
 c.restore()}
function kraftWall(){bg('#b98a57');for(let i=0;i<180;i++){c.fillStyle=hr(i)>.5?'rgba(255,230,190,.08)':'rgba(80,50,20,.1)';c.fillRect(hr(i*3)*W,hr(i*7)*H,2+hr(i)*40,2)}
 // pegboard
 patt('#c9a46a',()=>c.rect(820,60,420,300),1,'rgba(80,50,20,.35)',5);line([[880,120],[880,220]],'#5a5a66',8);line([[960,110],[1000,230]],'#5a5a66',6);stk('#e63946',()=>rr(1040,120,30,90,6),1.6,0);stk(FOIL,()=>ell(1160,180,36,24),1.6,0)}
function blueprint(x,y,w,h,inner,k=1,cross=0){if(k<=0)return;c.save();c.globalAlpha*=k;c.translate(x,y);c.rotate((hr(x)-.5)*.06);stk('#2f5f9e',()=>rr(-w/2,-h/2,w,h,4),2,6);
 c.save();c.strokeStyle='rgba(255,255,255,.18)';c.lineWidth=1;for(let i=-w/2;i<w/2;i+=18){c.beginPath();c.moveTo(i,-h/2);c.lineTo(i,h/2);c.stroke()}for(let j=-h/2;j<h/2;j+=18){c.beginPath();c.moveTo(-w/2,j);c.lineTo(w/2,j);c.stroke()}c.restore();
 fill('#c9c9cf',()=>circ(0,-h/2+10,6),0);c.save();c.strokeStyle='#f2f6ff';c.lineWidth=3;inner();c.restore();
 if(cross>0){const p=clamp01(cross);line([[-w/2+16,-h/2+16],[-w/2+16+(w-32)*Math.min(1,p*2),-h/2+16+(h-32)*Math.min(1,p*2)]],RED,9);if(p>.5)line([[w/2-16,-h/2+16],[w/2-16-(w-32)*(p-.5)*2,-h/2+16+(h-32)*(p-.5)*2]],RED,9)}
 c.restore()}
function turntable(x,y,t,spin){stk('#55565f',()=>ell(x,y,170,34),2.4,6);c.save();c.strokeStyle='rgba(255,255,255,.25)';c.lineWidth=3;c.beginPath();c.ellipse(x,y,140,26,0,spin*3,spin*3+1.4);c.stroke();c.restore()}
function flipBoard(x,y,rows,t,flip){stk('#1b1d24',()=>rr(x-360,y-150,720,300,14),2.6,10);
 rows.forEach((r,i)=>{const s=r.slice(0,14).padEnd(14);for(let j=0;j<14;j++){const cx=x-330+j*47,cy=y-110+i*72;fill('#2c2f38',()=>rr(cx,cy,42,58,4),0);fill('#111',()=>c.rect(cx,cy+28,42,2),0);
  let ch=s[j];if(flip>0&&flip<1&&ch!==' '){const k=Math.floor((flip*20+j*.7+i)%26);ch=String.fromCharCode(65+k)}c.save();c.font='700 38px Fredoka,sans-serif';c.fillStyle=i===rows.length-1?TAPE:'#f6f2e6';c.textAlign='center';c.fillText(ch,cx+21,cy+43);c.restore()}})}
function carousel(y,t){stk('#5a5e6a',()=>rr(-160,y,W+320,60,30),2.4,6);c.save();c.strokeStyle='rgba(255,255,255,.18)';c.lineWidth=3;for(let i=0;i<30;i++){const x=((i*60+t*40)%(W+320))-160;c.beginPath();c.moveTo(x,y+6);c.lineTo(x-14,y+54);c.stroke()}c.restore()}
function suitcase(x,y,s,col){stk(col,()=>rr(x-50*s,y-70*s,100*s,70*s,8*s),2,5);line([[x-18*s,y-70*s],[x-18*s,y-84*s],[x+18*s,y-84*s],[x+18*s,y-70*s]],INK,4*s)}
function luggageTag(x,y,txt,t){c.save();c.translate(x,y);c.rotate(Math.sin(t*1.5)*.1);line([[0,-30],[0,0]],INK,2);stk('#f6e2b0',()=>{c.moveTo(-30,0);c.lineTo(30,0);c.lineTo(30,50);c.lineTo(-30,50);c.closePath()},1.6,4);hand(txt,0,34,22,INK);c.restore()}
function palm(x,y,s,t,col='#1d3b2a'){line([[x,y],[x+10*s,y-200*s],[x+18*s,y-300*s]],'#4a3420',14*s);for(let i=0;i<6;i++){const a=-Math.PI+i/5*Math.PI+Math.sin(t+i)*.06;fill(col,()=>{c.moveTo(x+18*s,y-300*s);c.quadraticCurveTo(x+18*s+Math.cos(a)*90*s,y-300*s+Math.sin(a)*60*s-30*s,x+18*s+Math.cos(a)*160*s,y-300*s+Math.sin(a)*40*s+50*s);c.quadraticCurveTo(x+18*s+Math.cos(a)*80*s,y-300*s+Math.sin(a)*30*s,x+18*s,y-300*s)},0)}}
function neonFrame(x,y,w,h,t,col='255,80,180'){c.save();c.globalCompositeOperation='lighter';for(const [lw,a] of [[18,.15],[8,.35],[3,.95]]){c.strokeStyle=`rgba(${col},${a*(.85+.15*Math.sin(t*3))})`;c.lineWidth=lw;c.beginPath();rr(x,y,w,h,30);c.stroke()}c.restore()}
function garland(y,t){for(let i=0;i<46;i++){const x=-120+i*32,yy=y+Math.sin(clamp01((x+120)/(W+240))*Math.PI)*60+Math.sin(t*1.5+i)*2;stk('#fffdf2',()=>circ(x,yy,9),1.2,0);fill('#e8d98a',()=>circ(x,yy,3),0)}}
function balikbayan(x,y,s){stk('#c79a5a',()=>rr(x-46*s,y-60*s,92*s,60*s,4*s),2,5);fill('#2f5f9e',()=>c.rect(x-46*s,y-36*s,92*s,8*s),0);hand('MANILA',x,y-8*s,18*s,INK)}
function boardroom(t){sky('#9ab0c4','#e6ecf0');fill('#7a8aa0',()=>{c.rect(-160,380,W+320,40)},0);
 // London skyline, far layer
 fill('#5c6878',()=>{c.rect(900,150,50,240);c.moveTo(895,150);c.lineTo(925,90);c.lineTo(955,150)},3);stk('#f6f2e6',()=>circ(925,190,18),1.4,0);
 fill('#6c7888',()=>{c.rect(560,250,300,140);c.rect(990,230,200,160);c.rect(120,280,240,110)},2);
 // window mullions
 for(let i=0;i<6;i++)fill('#2a2e38',()=>c.rect(-160+i*290,-80,16,520),0);fill('#2a2e38',()=>c.rect(-160,420,W+320,16),0);
 fill('#3a3e4a',()=>c.rect(-160,436,W+320,H),0)}
function bigTable(){stk('#5a3a22',()=>{c.moveTo(80,560);c.lineTo(1200,560);c.lineTo(1300,740);c.lineTo(-20,740);c.closePath()},2.6,8);fill('rgba(255,255,255,.08)',()=>{c.moveTo(80,560);c.lineTo(1200,560);c.lineTo(1210,580);c.lineTo(70,580)},0)}
function livingRoom(t){bg('#f1d7a8');patt('#f3dcae',()=>c.rect(-160,-80,W+320,500),3,'rgba(200,120,60,.18)',0);fill('#c98c5a',()=>c.rect(-160,420,W+320,40),2);
 // tiled floor
 fill('#e8c9a0',()=>c.rect(-160,460,W+320,H),2);c.save();c.strokeStyle='rgba(120,70,30,.18)';for(let i=0;i<14;i++){c.beginPath();c.moveTo(-160+i*120,460);c.lineTo(-600+i*180,H+80);c.stroke()}c.restore();
 // window with a capiz-free jalousie and an electric fan
 stk('#7aa8c8',()=>rr(70,90,200,220,6),2.4,8);for(let i=0;i<8;i++)fill('rgba(255,255,255,.4)',()=>c.rect(80,104+i*26,180,8),0);
 const fa=t*14;stk('#e6eef2',()=>circ(1150,250,62),2,6);c.save();c.translate(1150,250);c.rotate(fa);for(let i=0;i<3;i++){c.rotate(Math.PI*2/3);fill('#7fd3f0',()=>ell(0,-30,14,28),0)}c.restore();stk('#fffdf4',()=>circ(1150,250,10),1.6,0);line([[1150,312],[1150,420]],INK,6);stk('#e6eef2',()=>ell(1150,424,40,10),2,0)}
function videokeTV(x,y,t,score){stk('#222',()=>rr(x-180,y-110,360,220,12),2.6,8);const g=c.createLinearGradient(0,y-96,0,y+96);g.addColorStop(0,'#2a6fd8');g.addColorStop(1,'#7cd0ff');c.fillStyle=g;c.fillRect(x-166,y-96,332,192);
 hand('♪ My Way ♪',x,y-40,30,'#fff');fill('#f4c430',()=>c.rect(x-140,y+10,280*((t*.06)%1),10),0);if(score)hand(score,x,y+70,44,'#fffd8a');stk('#3a3a44',()=>rr(x-60,y+110,120,40,6),2,0)}
function monobloc(x,y,s,turn,person){const k=Math.cos(clamp01(turn)*Math.PI),w=Math.max(.06,Math.abs(k));c.save();c.translate(x,y);c.scale(w,1);
 [[-40],[40]].forEach(([dx])=>line([[dx*s,-70*s],[dx*s*1.2,0]],'#e9ecef',8*s));
 if(k>0){stk('#f4f6f8',()=>rr(-52*s,-160*s,104*s,100*s,24*s),2,5);person&&person(true)}
 else{person&&person(false);stk('#f4f6f8',()=>rr(-54*s,-74*s,108*s,18*s,8*s),2,4)}
 c.restore()}
// family: round paper-doll people (new design for this video)
function doll(s,o,front,t){const sk=o.skin||'#c48f62';if(!front){stk(o.hair||'#1a1a1a',()=>circ(0,-190*s,30*s),2,4);if(o.bun)stk(o.hair,()=>circ(0,-222*s,13*s),1.6,0);return}
 stk(o.shirt,()=>{c.moveTo(-36*s,-60*s);c.quadraticCurveTo(-38*s,-150*s,0,-152*s);c.quadraticCurveTo(38*s,-150*s,36*s,-60*s);c.closePath()},2,5);
 stk(sk,()=>circ(0,-188*s,28*s),2,5);stk(o.hair||'#1a1a1a',()=>{c.arc(0,-192*s,30*s,Math.PI*1.02,Math.PI*1.98);c.closePath()},1.6,0);if(o.bun)stk(o.hair,()=>circ(0,-222*s,13*s),1.6,0);
 if(o.glasses){c.save();c.strokeStyle=INK;c.lineWidth=2*s;c.beginPath();circ(-10*s,-188*s,7*s);circ(10*s,-188*s,7*s);c.stroke();c.restore()}
 fill(INK,()=>{circ(-10*s,-188*s,3*s);circ(10*s,-188*s,3*s)},0);c.save();c.strokeStyle=INK;c.lineWidth=2.4*s;c.beginPath();c.arc(0,-178*s,9*s,.2,Math.PI-.2);c.stroke();c.restore();
 if(o.cheer){[[-1],[1]].forEach(([f])=>{c.save();c.translate(f*30*s,-140*s);c.rotate(f*(-2.5+Math.sin(t*7+f)*.2));stk(o.shirt,()=>rr(-6*s,0,12*s,44*s,6*s),1.6,0);c.restore()})}}

/* ---- ON AIR chapter light box ---- */
function onAir(title,a,t){if(a<=0)return;c.save();c.globalAlpha=a;c.translate(70,36-(1-EASE(a))*100);stk('#1b1d24',()=>rr(0,0,430,120,14),2.6,8);
 const on=.75+.25*Math.sin(t*5);stk(`rgba(215,38,61,${on})`,()=>rr(18,18,140,40,8),1.6,0);c.font='900 26px Fredoka,sans-serif';c.fillStyle='#fff';c.fillText('ON AIR',36,47);glow(88,38,70,'255,60,80',.3*on);
 c.font='900 34px Fredoka,sans-serif';c.fillStyle='#fff6dc';c.fillText(title,20,100);c.restore()}
