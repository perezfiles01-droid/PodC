
/* ================= EDRMS: messy paper office -> paper library (manila tabs, drawers, labels) ================= */
function K(li,from,word,dur=.9){if(li<from)return 0;if(li>from)return 1;return word?RW(word,dur):EASE(clamp01(lt()/dur))}
function walkX(li,from,x0,x1,dur=2.2,word=null){if(li<from)return [x0,false];if(li>from)return [x1,false];const d=word?since(word):lt();if(d<0)return [x0,false];const p=clamp01(d/dur);return [x0+(x1-x0)*SM(p),p<1]}
// new design: "Docs", little paper sheets with eyes and feet
function doc(x,y,s,t,o={}){const col=o.col||'#fffdf4';const bob=o.walk?Math.abs(Math.sin(t*8))*6*s:Math.sin(t*2+x)*2*s;c.save();c.translate(x,y-bob);c.rotate(o.rot||0);
 if(o.walk){const st=Math.sin(t*8);line([[-12*s,0],[-12*s+st*8*s,18*s]],INK,4*s);line([[12*s,0],[12*s-st*8*s,18*s]],INK,4*s)}else{line([[-12*s,0],[-12*s,16*s]],INK,4*s);line([[12*s,0],[12*s,16*s]],INK,4*s)}
 stk(col,()=>{c.moveTo(-34*s,-110*s);c.lineTo(18*s,-110*s);c.lineTo(34*s,-94*s);c.lineTo(34*s,0);c.lineTo(-34*s,0);c.closePath()},2.2,6);
 fill('#d8d2c2',()=>{c.moveTo(18*s,-110*s);c.lineTo(18*s,-94*s);c.lineTo(34*s,-94*s)},0);
 for(let k=0;k<4;k++)fill('rgba(60,60,80,.25)',()=>c.rect(-24*s,-40*s+k*9*s,48*s,3*s),0);
 const ey=-76*s;[-11,11].forEach(dx=>{stk('#fff',()=>circ(dx*s,ey,8*s),1.4,0);fill(INK,()=>circ(dx*s+(o.look||0)*3*s,ey+1*s,3.6*s),0)});
 c.save();c.strokeStyle=INK;c.lineWidth=2.2*s;c.beginPath();if(o.worry)c.arc(0,ey+22*s,7*s,3.5,5.9);else c.arc(0,ey+12*s,8*s,.3,Math.PI-.3);c.stroke();c.restore();
 if(o.sweat)fill('#8fd3ff',()=>ell(28*s,ey-10*s,3.5*s,5.5*s),0);
 if(o.name)hand(o.name,0,-118*s,15*s,'#c0262d');
 if(o.lock){stk('#f4c430',()=>rr(-12*s,-30*s,24*s,20*s,4*s),1.6,0);c.save();c.strokeStyle=INK;c.lineWidth=3*s;c.beginPath();c.arc(0,-30*s,8*s,Math.PI,0);c.stroke();c.restore()}
 if(o.seal)stk('#f4c430',()=>{for(let k=0;k<12;k++){const a=k/12*Math.PI*2,r=k%2?12:16;c.lineTo(22*s+Math.cos(a)*r*s,-16*s+Math.sin(a)*r*s)}c.closePath()},1.4,0);
 c.restore()}
const LOST={name:'final_FINAL_v7',col:'#ffe9b0'};
function office(t){bg('#d9e3ea');patt('#d2dde6',()=>c.rect(-160,-80,W+320,460),1,'rgba(60,90,120,.15)',0);
 stk('#fffdf4',()=>rr(900,70,240,170,6),2,6);hand('IN',1020,170,60,'#9aa4b4');fill('#7a8aa0',()=>c.rect(-160,420,W+320,H),4);
 wood('#a8794a',()=>rr(160,400,960,60,6),6,2);fill('#6b4a2a',()=>{c.rect(200,460,20,200);c.rect(1060,460,20,200)},3)}
function pile(x,y,n){for(let i=0;i<n;i++)stk(i%3?'#fffdf4':'#f0eadb',()=>rr(x-70+(hr(i)-.5)*30,y-i*9,140,10,2),1.2,0)}
function library(t){bg('#f3e4c4');rays(640,-60,'255,235,190',7,900,.12,t);
 for(let s=0;s<4;s++){const x=60+s*300;wood('#8a5a2e',()=>c.rect(x,90,260,360),5,s+1);for(let r=0;r<3;r++){fill('#5a3a1e',()=>c.rect(x+10,190+r*110,240,10),0);for(let b=0;b<9;b++)stk(['#e63946','#3a6fd8','#f4c430','#2bb3a3','#b9a3e3'][(b+r+s)%5],()=>rr(x+16+b*26,120+r*110,22,70,3),1.2,0)}}
 fill('#c49a6a',()=>c.rect(-160,450,W+320,H),4)}
function maze(t){bg('#1b1f3b');c.save();c.strokeStyle='#3a6fd8';c.lineWidth=10;for(let i=0;i<9;i++){c.beginPath();c.moveTo(80+i*130,80+(i%2)*120);c.lineTo(80+i*130,560-(i%3)*90);c.stroke()}for(let j=0;j<5;j++){c.beginPath();c.moveTo(80+j*60,140+j*90);c.lineTo(800-j*40,140+j*90);c.stroke()}c.restore()}
function dashWall(t,li){bg('#eef2f6');fill('#c8d0da',()=>c.rect(-160,470,W+320,H),4);
 [['DECLARED','#2f5f9e'],['ACTIVE SITES','#2bb3a3'],['STORAGE','#e8743b'],['DUE FOR REVIEW','#c0262d']].forEach(([n,col],i)=>{const x=100+i*280,y=110;stk('#fffdf4',()=>rr(x,y,240,300,12),2.2,8);fill(col,()=>c.rect(x,y,240,46),0);hand(n,x+120,y+34,24,'#fff');
  for(let k=0;k<5;k++){const h=40+hr(i*7+k)*110+Math.sin(t*1.5+k+i)*10;fill(col,()=>c.rect(x+28+k*40,y+270-h,26,h),0)}})}

const S=[
{chap:'Every office makes paper',lines:[
 'Every office makes paper. Letters, reports, contracts, and a lot of files called "final".',
 'Some of those files are just drafts. But some are records: proof of a decision, a deal, or a promise.'],
 draw(t,li){PL(t,.3,()=>office(t));
  PL(t,1,()=>{pile(380,400,14);pile(640,400,20);pile(900,400,11);
   const up=li===0?RW('final',1):1;doc(640,560-up*40,1.2,t,{...LOST,worry:true,look:Math.sin(t)});
   if(li===1){withA(K(li,1,'drafts'),()=>{c.save();c.translate(300,300);c.rotate(-.06);doc(0,0,1.3,t,{});hand('draft',0,30,30,'#9aa4b4');c.restore()});
    withA(K(li,1,'records'),()=>{c.save();c.translate(980,300);c.rotate(.05);doc(0,0,1.3,t,{seal:true});hand('record',0,30,30,'#c0262d');c.restore()})}});}},

{chap:'Where files hide',lines:[
 'Without a system, records hide everywhere: in email, on laptops, in shared drives.',
 'And when someone asks, "Where is the signed version?", everybody suddenly gets very busy.'],
 draw(t,li){PL(t,.3,()=>{if(li===0){bg('#20253a');[['EMAIL','#e63946'],['LAPTOP','#3a6fd8'],['SHARED DRIVE','#2bb3a3']].forEach(([n,col],i)=>{const x=40+i*410;stk(col,()=>rr(x,60,380,500,14),2.4,6);hand(n,x+190,120,40,'#fff');for(let k=0;k<6;k++)stk('#fffdf4',()=>rr(x+40+(k%3)*110,180+Math.floor(k/3)*150,80,110,4),1.2,0)})}else office(t)});
  PL(t,1,()=>{if(li===0){const p=(lt()*.18)%1;doc(80+p*1100,600,.9,t,{...LOST,walk:true,worry:true,sweat:true})}
   else{[340,640,940].forEach((x,i)=>{silP(x,620,.9,t,{pop:['#e63946','#3a6fd8','#f4c430'][i],hair:'#2a1d14'});if(since('busy')>=0){stk('#2a2e3a',()=>rr(x-60,470,120,40,6),1.6,0);for(let k=0;k<5;k++)fill('#fff',()=>c.rect(x-50+k*22,478+(Math.sin(t*30+k)>0?0:4),16,8),0)}});
    withA(K(li,1,'where'),()=>bubble(640,170,520,80,'Where is the signed version?','#fffdf4',INK,32))}});}},

{chap:'Enter the EDRMS',lines:[
 'That is where an EDRMS comes in: an Electronic Document and Records Management System.',
 'Think of it as one well-organized library for an organization\'s documents.'],
 draw(t,li){PL(t,.3,()=>library(t));
  PL(t,1,()=>{const L=['E','D','R','M','S'],W2=['Electronic','Document','Records','Management','System'];
   L.forEach((ch,i)=>{const a=li===0?RW(W2[i].toLowerCase(),.8):1;withA(1,()=>{stk('#fffdf4',()=>rr(250+i*160,470,130,110,10),2.4,8);hand(ch,315+i*160,555,80,'#2f5f9e');withA(a,()=>hand(W2[i],315+i*160,620,22,INK))})});
   if(li===1)['Finance','Projects','HR','Legal'].forEach((n,i)=>tag(190+i*300,70,n,RW('library',.8+i*.2),'#fffdf4',INK,24))});}},

{chap:'How it works',lines:[
 'Step one: you save your work in the right place, a team or project site, instead of your desktop.',
 'Step two: when a document becomes official, you declare it as a record.',
 'Once declared, it is locked. No more sneaky edits after the fact.',
 'Step three: the system attaches a label that says what it is, who owns it, and how long to keep it.'],
 draw(t,li){PL(t,.3,()=>{bg('#e8eef4');patt('#e0e8f0',()=>c.rect(-160,-80,W+320,H+160),3,'rgba(47,95,158,.08)',0);fill('#c8d0da',()=>c.rect(-160,520,W+320,H),4)});
  PL(t,1,()=>{stk('#2a2e3a',()=>rr(80,200,300,200,12),2.4,6);fill('#7fd3f0',()=>c.rect(96,214,268,170),0);hand('DESKTOP',230,440,28,INK);
   stk('#f4c430',()=>{c.moveTo(860,250);c.lineTo(960,250);c.lineTo(980,280);c.lineTo(1180,280);c.lineTo(1180,460);c.lineTo(860,460);c.closePath()},2.4,6);hand('PROJECT SITE',1020,320,30,INK);
   const [dx,dw]=walkX(li,0,230,1010,3,'right');
   const o={walk:dw,lock:li>=2||(li===1&&since('declare')>=0),seal:li>=1&&since('declare')>=0||li>=2};
   doc(dx,li===0&&!dw&&dx<500?330:470,1,t,o);
   if(li>=1)withA(K(li,1,'declare'),()=>{c.save();c.translate(1010,170);c.rotate(-.1);stamp('DECLARED',0,0,1,'#c0262d');c.restore()});
   if(li===2){const s=since('sneaky');if(s>=0){const p=Math.min(1,s/.6),bx=1150-p*90+(s>.6?Math.sin((s-.6)*20)*10*Math.exp(-(s-.6)*3):0);c.save();c.translate(bx,330);c.rotate(-.8);stk('#f4c430',()=>rr(-8,-70,16,90,3),1.6,0);fill('#f6c4a0',()=>{c.moveTo(-8,20);c.lineTo(8,20);c.lineTo(0,36)},0);c.restore();if(s>.6&&s<1.4)hand('boing!',1180,250,30,'#c0262d')}}
   if(li===3)withA(K(li,3,'label'),()=>{c.save();c.translate(800,330);c.rotate(Math.sin(t*1.5)*.06);line([[150,-30],[60,0]],INK,2);stk('#f6e2b0',()=>{c.moveTo(-170,-40);c.lineTo(60,-40);c.lineTo(90,0);c.lineTo(60,40);c.lineTo(-170,40);c.closePath()},1.8,4);hand('Contract | Legal | Keep 10 years',-50,10,22,INK);c.restore()})});}},

{chap:'The records clock',lines:[
 'That last part is called retention. Some records are kept for a few years, some forever.',
 'When the time is up, the record is reviewed and, if it is no longer needed, disposed of safely, with a note of what was removed.'],
 draw(t,li){PL(t,.3,()=>library(t));
  PL(t,1,()=>{[[260,.7,'3 yrs'],[460,1,'7 yrs'],[660,1.3,'10 yrs'],[860,1.1,'∞']].forEach(([x,s,l],i)=>{const a=li===0?RW(i===3?'forever':'years',.8):1;withA(a,()=>{c.save();c.translate(x,520);stk('#f6e2b0',()=>{c.moveTo(-30*s,-80*s);c.lineTo(30*s,-80*s);c.lineTo(0,0);c.lineTo(30*s,80*s);c.lineTo(-30*s,80*s);c.lineTo(0,0);c.closePath()},2,4);const f=(t*.1+i*.2)%1;fill('#e8c35a',()=>{c.moveTo(-26*s*(1-f),-76*s+70*s*f);c.lineTo(26*s*(1-f),-76*s+70*s*f);c.lineTo(0,-2)},0);c.restore();hand(l,x,640,26,INK)})});
   if(li===1){const [rx,rw]=walkX(li,1,860,1080,2,'reviewed');doc(rx,450,.7,t,{walk:rw});stk('#5a5e6a',()=>rr(1040,470,120,110,8),2,4);hand('REVIEW',1100,540,22,'#fff');
    if(since('disposed')>=0){const p=clamp01(since('disposed')/1.4);stk('#fffdf4',()=>rr(1180,560-p*80,70,p*80+4,2),1.2,0);hand('logged',1215,620,18,'#2f5f9e')}}});}},

{chap:'Why bother?',lines:[
 'It means you can find things quickly, prove what happened, and follow the rules.',
 'It also saves space, because the system knows what to keep and what to let go.'],
 draw(t,li){PL(t,.3,()=>library(t));
  PL(t,1,()=>{[['find',300,'🔍 found it'],['prove',640,'✔ proof'],['rules',980,'📘 rules']].forEach(([w,x,l])=>tag(x,180,l,vis(li,0,w,0),'#fffdf4',INK,30));
   if(li===1){const p=RW('saves',2);stk('#fffdf4',()=>rr(340,380,600,60,30),2.4,6);fill(p>.5?'#2bb3a3':'#e63946',()=>rr(350,390,580*(1-p*.6),40,20),0);hand('storage',640,500,30,INK)}});}},

{chap:'Is it working?',lines:[
 'And how do you know people are actually using it? You measure it.',
 'Dashboards show how many records are declared, which sites are active, how much storage is used, and what is due for review.'],
 draw(t,li){PL(t,.3,()=>dashWall(t,li));PL(t,1,()=>{if(li===0)withA(K(li,0,'measure'),()=>{c.save();c.translate(640,560);stk('#f4c430',()=>rr(-260,-20,520,40,6),2,4);for(let k=0;k<26;k++)line([[-250+k*20,-20],[-250+k*20,k%5?-6:4]],INK,2);c.restore()})});}},

{chap:'Home at last',lines:[
 'So, our lost file? Saved in the right site, declared, labelled, and shelved.',
 'An EDRMS is not just storage. It is an organization\'s memory, kept in order.'],
 draw(t,li){PL(t,.3,()=>library(t));
  PL(t,1,()=>{const up=li===0?RW('shelved',1.6):1;doc(640,560-up*260,1,t,{...LOST,lock:li===0?since('declared')>=0:true,worry:false,walk:li===0&&up>0&&up<1});
   if(li===0&&since('labelled')>=0||li===1)tag(640,560-up*260-150,'Kept 10 years',1,'#f6e2b0',INK,18);
   if(li===1&&since('memory')>=0){const a=SM(clamp01((since('memory')-.6)/1.6));c.save();c.globalAlpha=a;titleCard(t);c.restore()}});}}
];

const SHOTS={'3.2':['push',1.22,980,380]};
S.forEach((sc,si)=>{const base=sc.draw;sc.draw=function(t,li){const key=si+'.'+li,sp=SHOTS[key];
  const isCur=window.CL&&window.CL.s===si,savedCL=window.CL;if(window.CL&&!isCur)window.CL={s:si,l:li,lt:99};const L=isCur?lt():99;
  let z=1,cx=W/2,cy=H/2;if(sp){cx=sp[2];cy=sp[3];const dl=(window.TL||[]).find(x=>x[0]===si&&x[1]===li);const D=dl?dl[3]-dl[2]:4;z=1+(sp[1]-1)*(SM(clamp01(L/1.4))-SM(clamp01((L-D+.2)/1.4)))}
  c.save();if(z!==1){c.translate(W/2,H/2);c.scale(z,z);c.translate(-cx,-cy)}
  base.call(this,t,li);c.restore();
  if(si>=1&&li===0&&t<7.6)onAir(sc.chap,clamp01((t-4.2)/.6)*clamp01((7.6-t)/.7),t);
  window.CL=savedCL}});
window.since=function(word){const k=window.CL;if(!k)return 99;const Lw=(WORDS[k.s]||{})[k.l]||[];const w=word.toLowerCase();const hit=Lw.find(x=>x[0]===w||x[0].startsWith(w));if(!hit)return -1;
 let g=Math.floor(hit[1]/1.8)*1.8;const rw=(window.TL||[]).find(x=>x[0]===k.s&&x[1]===k.l);if(rw)g=Math.min(g,Math.max(0,(rw[3]-rw[2])-2.5));const d=k.lt-g;return d>=0?d:-1};
window.FONTS=Promise.all(["700 40px Caveat","900 40px Fredoka","700 40px Fredoka","700 25px Nunito"].map(f=>document.fonts.load(f)));
</script>
