
/* ================= SB19: rehearsal-room paper diorama (mirrors, floor tape, count-in numbers) ================= */
function K(li,from,word,dur=.9){if(li<from)return 0;if(li>from)return 1;return word?RW(word,dur):EASE(clamp01(lt()/dur))}
function walkX(li,from,x0,x1,dur=2.2,word=null){if(li<from)return [x0,false];if(li>from)return [x1,false];const d=word?since(word):lt();if(d<0)return [x0,false];const p=clamp01(d/dur);return [x0+(x1-x0)*SM(p),p<1]}
// five dancers: new design for this story, paper "cut-out" bodies with a coloured jacket stripe
const CREW=[['PABLO','#e63946','#1a1a1a'],['JOSH','#3a6fd8','#2a1d14'],['STELL','#f4c430','#3a2214'],['KEN','#2bb3a3','#111'],['JUSTIN','#b9a3e3','#4a2a1a']];
function dancer(x,y,s,t,i,o={}){const [,jc,hc]=CREW[i];const mv=o.dance?Math.sin(t*6+i):0,bob=o.dance?Math.abs(Math.sin(t*6+i))*10*s:0;
 c.save();c.translate(x,y-bob);
 [[-12,mv*.5],[12,-mv*.5]].forEach(([dx,a])=>{c.save();c.translate(dx*s,-70*s);c.rotate(a);stk('#2b2b3a',()=>rr(-8*s,0,16*s,70*s,7*s),2,0);stk('#f6f2e6',()=>ell(5*s,70*s,14*s,7*s),1.6,0);c.restore()});
 stk('#f6f2e6',()=>rr(-30*s,-160*s,60*s,96*s,18*s),2.4,6);fill(jc,()=>{c.rect(-30*s,-160*s,16*s,92*s);c.rect(14*s,-160*s,16*s,92*s)},0);
 const arm=(f)=>{c.save();c.translate(f*30*s,-152*s);c.rotate(o.cheer?f*-2.6+Math.sin(t*8)*.2*f:o.dance?f*(.4+Math.sin(t*6+i+f)*1.1):f*.2);stk('#f6f2e6',()=>rr(-7*s,0,14*s,60*s,7*s),2,0);stk('#c99a72',()=>circ(0,64*s,8*s),1.4,0);c.restore()};arm(-1);arm(1);
 const hy=-196*s;stk('#c99a72',()=>circ(0,hy,30*s),2.4,6);stk(hc,()=>{c.moveTo(-32*s,hy-2*s);c.quadraticCurveTo(-30*s,hy-40*s,0,hy-38*s);c.quadraticCurveTo(34*s,hy-40*s,32*s,hy-4*s);c.lineTo(10*s,hy-16*s);c.closePath()},2,0);
 if(o.tired){c.save();c.strokeStyle=INK;c.lineWidth=2.4*s;[-1,1].forEach(f=>{c.beginPath();c.moveTo(f*16*s,hy+2*s);c.lineTo(f*6*s,hy+2*s);c.stroke()});c.restore()}
 else fill(INK,()=>{circ(-11*s,hy,3.4*s);circ(11*s,hy,3.4*s)},0);
 c.save();c.strokeStyle=INK;c.lineWidth=2.6*s;c.beginPath();if(o.tired)c.arc(0,hy+18*s,7*s,3.5,5.9);else c.arc(0,hy+8*s,9*s,.3,Math.PI-.3);c.stroke();c.restore();
 if(o.sweat)for(let k=0;k<2;k++){const p=(t*.9+k*.5+i*.2)%1;fill('#8fd3ff',()=>ell((24+k*6)*s,hy-10*s+p*30*s,3.5*s,5.5*s),0)}
 c.restore()}
// the running gag: a paper mop with googly eyes that keeps mopping the sweat
function mop(x,y,s,t,o={}){const sw=o.dance?Math.sin(t*6)*.35:Math.sin(t*2.4)*.12;c.save();c.translate(x,y);c.rotate(sw);
 line([[0,0],[0,-230*s]],'#b07a45',10*s);for(let i=-5;i<=5;i++)line([[0,-10*s],[i*9*s+Math.sin(t*5+i)*4*s,40*s]],'#e8e2d0',7*s);
 const ey=-170*s;[[-9],[9]].forEach(([dx])=>{stk('#fff',()=>circ(dx*s,ey,9*s),1.4,0);fill(INK,()=>circ(dx*s+Math.sin(t*3)*3*s,ey+2*s,4*s),0)});
 if(o.dance){c.save();c.strokeStyle=INK;c.lineWidth=2*s;c.beginPath();c.arc(0,ey+16*s,8*s,.2,Math.PI-.2);c.stroke();c.restore()}
 c.restore();if(o.puddle)fill('rgba(140,200,255,.55)',()=>ell(x+40*s,y+42*s,46*s,8*s),0)}
function practiceRoom(t,night=true){bg(night?'#20253a':'#e9e1d0');
 // mirror wall
 for(let i=0;i<5;i++){const x=-140+i*300;stk(night?'#3a4466':'#cfe0ea',()=>c.rect(x,60,286,380),2,4);c.save();c.globalAlpha=.25;line([[x+30,90],[x+120,400]],'#fff',10);line([[x+150,90],[x+200,250]],'#fff',6);c.restore()}
 fill('#6b4a2a',()=>c.rect(-160,440,W+320,14),2);
 wood(night?'#7a5634':'#b8885a',()=>c.rect(-160,454,W+320,H),6,4);
 // floor tape marks
 [200,420,640,860,1080].forEach((x,i)=>{line([[x-18,610],[x+18,610]],TAPE,6);hand(String(i+1),x,640,22,TAPE)});
 if(night){const g=c.createRadialGradient(640,40,10,640,40,700);g.addColorStop(0,'rgba(255,240,200,.25)');g.addColorStop(1,'rgba(255,240,200,0)');c.fillStyle=g;c.fillRect(-160,-80,W+320,H+160)}}
function clock(x,y,t,h=2){stk('#fffdf4',()=>circ(x,y,44),2,6);line([[x,y],[x+Math.cos(-Math.PI/2+h/12*Math.PI*2)*22,y+Math.sin(-Math.PI/2+h/12*Math.PI*2)*22]],INK,5);line([[x,y],[x+Math.cos(t*.5)*34,y+Math.sin(t*.5)*34]],INK,3)}
function auditionHall(t){bg('#d9cfe8');patt('#cfc3e2',()=>c.rect(-160,-80,W+320,460),1,'rgba(90,60,140,.18)',0);fill('#8a7aa8',()=>c.rect(-160,420,W+320,H),4);
 stk('#fffdf4',()=>rr(330,70,620,110,10),2.4,8);hand('AUDITIONS TODAY',640,140,52,'#5a3a8a');
 stk('#5a4a3a',()=>rr(900,430,320,40,6),2.4,6);for(let i=0;i<3;i++){silP(960+i*90,430,.55,t,{pop:['#e63946','#3a6fd8','#f4c430'][i],hair:'#111',face:-1})}}
function calendarWall(t,n){bg('#f3e4c4');patt('#f0dfbc',()=>c.rect(-160,-80,W+320,H+160),2,'rgba(160,110,60,.1)',0);
 for(let m=0;m<36;m++){const x=120+(m%12)*90,y=70+Math.floor(m/12)*110;stk('#fffdf4',()=>rr(x,y,78,92,4),1.6,4);fill('#e63946',()=>c.rect(x,y,78,18),0);if(m<n){line([[x+12,y+30],[x+66,y+84]],RED,5);line([[x+66,y+30],[x+12,y+84]],RED,5)}}
 fill('#a8794a',()=>c.rect(-160,430,W+320,H),4)}
function mallStage(t){bg('#f6efe2');fill('#e2d6c0',()=>c.rect(-160,-80,W+320,300),0);for(let i=0;i<8;i++)stk('#fffdf4',()=>rr(-100+i*190,60,150,150,6),1.6,4);
 fill('#cdbda2',()=>c.rect(-160,380,W+320,H),4);stk('#7a2e3a',()=>rr(260,300,760,110,8),2.6,8);
 bunting(40,t,['#e63946','#3a6fd8','#f4c430'])}
function phoneWall(t,n){bg('#141826');for(let i=0;i<n;i++){const x=80+(i%10)*125,y=60+Math.floor(i/10)*170;c.save();c.translate(x,y);stk('#2a2e3a',()=>rr(-44,0,88,150,12),2,4);fill('#ffe9b0',()=>c.rect(-36,12,72,118),0);
 for(let k=0;k<5;k++)fill(CREW[k][1],()=>circ(-24+k*12,70+Math.sin(t*6+k+i)*6,5),0);c.restore()}}
function chartBoard(t){bg('#101420');patt('#151a2a',()=>c.rect(-160,-80,W+320,H+160),2,'rgba(255,255,255,.03)',0);
 stk('#1d2336',()=>rr(160,60,960,520,16),2.6,10);hand('BILLBOARD',640,130,56,'#fff6dc');
 for(let r=0;r<6;r++){fill(r===2?'rgba(244,196,48,.25)':'rgba(255,255,255,.05)',()=>rr(200,170+r*62,880,52,6),0);hand(String(r+1),240,206+r*62,32,'#aab')}}
function arena(t){bg('#08070f');for(let i=0;i<260;i++){const x=hr(i)*W,y=360+hr(i*3)*360,ph=t*3+i;fill(`rgba(${i%2?'255,214,90':'140,190,255'},${.4+.4*Math.sin(ph)})`,()=>circ(x,y,3+hr(i*5)*2),0)}
 rays(640,-40,'255,230,180',9,900,.12,t);stk('#22243a',()=>rr(120,330,1040,60,8),2.4,6)}

const S=[
{chap:'Two in the morning',lines:[
 'Five young men in a practice room, dancing until two in the morning.',
 'Nobody knew their names yet. Not even the mop in the corner.'],
 draw(t,li){PL(t,.3,()=>{practiceRoom(t);clock(1120,150,t,2)});
  PL(t,1,()=>{[200,420,640,860,1080].forEach((x,i)=>dancer(x,600,1,t,i,{dance:li===0||since('nobody')<0,sweat:true,tired:li===1&&since('mop')>=0}));
   mop(1210,620,.9,t,{puddle:true});
   if(li===1)withA(RW('names',1),()=>{[200,420,640,860,1080].forEach(x=>tag(x,330,'???',1,'#fffdf4',INK,22))})});}},

{chap:'Manila, 2016',lines:[
 'In twenty sixteen, a Korean entertainment company, ShowBT, came to Manila looking for future stars.',
 'Their plan: train Filipino performers the K-pop way. Singing, dancing, and endless practice.',
 'Trainees came and went. In the end, five stayed: Pablo, Josh, Stell, Ken, and Justin.'],
 draw(t,li){PL(t,.3,()=>auditionHall(t));
  PL(t,1,()=>{withA(vis(li,0,'sixteen',1),()=>stamp('2016',200,140,1,'#5a3a8a'));
   tag(1050,330,'ShowBT',vis(li,0,'showbt',2),'#fffdf4',INK,24);
   if(li===1)withA(K(li,1,null),()=>{[['SING ♪',330],['DANCE',640],['PRACTICE x ∞',950]].forEach(([w,x])=>tag(x,250,w,1,'#fffdf4','#5a3a8a',28))});
   // a queue of trainees: extra ones walk out on line 2, five stay
   const go=li===2?RW('went',1.8):0;
   for(let i=0;i<7;i++){const stay=i<5,base=120+i*110;let x=base;if(!stay)x=base+go*700;if(li>=2&&stay)x=200+i*220-(1-RW('stayed',1.6))*(200+i*220-base);
    if(stay)dancer(x,620,.9,t,i,{});else if(go<1)silP(x,620,.8,t,{walk:go>0,pop:'#888',hair:'#222'})}
   if(li===2)CREW.forEach(([n],i)=>tag(200+i*220,360,n,RW(n.toLowerCase(),.8),'#fffdf4',INK,22))});}},

{chap:'Three years of practice',lines:[
 'They trained for about three years. Same songs, same steps, again and again.',
 'Some days the only audience was a wall of mirrors. And the mop.'],
 draw(t,li){PL(t,.3,()=>calendarWall(t,li===0?Math.floor(clamp01(Math.max(0,since('trained'))/4)*36):36));
  PL(t,1,()=>{[200,420,640,860,1080].forEach((x,i)=>dancer(x,640,.85,t,i,{dance:true,sweat:true}));
   mop(1210,650,.8,t,{puddle:li===1,dance:li===1&&since('mop')>=0})});}},

{chap:'Debut, 2018',lines:[
 'On October twenty-sixth, twenty eighteen, SB19 finally debuted with a ballad called Tilaluha.',
 'Hardly anyone noticed. It was a very quiet start.'],
 draw(t,li){PL(t,.3,()=>mallStage(t));
  PL(t,1,()=>{withA(vis(li,0,'october',1),()=>stamp('2018',1080,150,1,'#7a2e3a'));tag(640,180,'TILALUHA',vis(li,0,'tilaluha',1),'#fffdf4','#7a2e3a',30);
   [380,510,640,770,900].forEach((x,i)=>dancer(x,390,.75,t,i,{dance:li===0}));
   // the tiny audience: one shopper with bags, one clap
   const [sx,sw]=walkX(li,1,-100,560,3);silP(li===1?sx:-200,700,.7,t,{walk:sw,pop:'#f28fb1',hair:'#3a2214'});
   if(li===1&&since('quiet')>=0){hand('clap.',sx+50,520,30,INK)}});}},

{chap:'Go Up, 2019',lines:[
 'In twenty nineteen they released Go Up, and posted a video of themselves practicing the dance.',
 'That practice video started spreading online. Share after share, view after view.',
 'All those late nights of practice were suddenly on phones all over the country.'],
 draw(t,li){const n=li===0?1:li===1?Math.floor(1+clamp01(Math.max(0,since('spreading'))/3)*29):30;
  PL(t,.3,()=>phoneWall(t,n));
  PL(t,1,()=>{if(li===0){c.save();c.translate(640,360);c.scale(2.6,2.6);c.translate(-80,-60);stk('#2a2e3a',()=>rr(-44,0,88,150,12),2,4);c.restore()}
   withA(vis(li,0,'nineteen',1),()=>stamp('2019',220,620,1,'#f4c430'));tag(640,90,'GO UP',vis(li,0,'go',2),'#f4c430',INK,40);
   if(li===2)withA(K(li,2,null),()=>mop(1180,620,.7,t,{dance:true}))});}},

{chap:'Billboard',lines:[
 'In November twenty nineteen, SB19 became the first Filipino act on Billboard\'s Next Big Sound chart.',
 'Weeks later, they entered the Billboard Social 50. Their fans, called A\'TIN, made sure of it.',
 'In twenty twenty-one, they were even nominated for Top Social Artist at the Billboard Music Awards.'],
 draw(t,li){PL(t,.3,()=>chartBoard(t));
  PL(t,1,()=>{const rows=li===0?['NEXT BIG SOUND','','SB19','','','']:li===1?['SOCIAL 50','','SB19','','','']:['TOP SOCIAL ARTIST','','SB19 (nominee)','','',''];
   rows.forEach((r,i)=>{if(r)hand(r,640,206+i*62,34,i===2?'#f4c430':'#fff6dc')});
   withA(vis(li,0,'first',0),()=>tag(640,620,'FIRST FILIPINO ACT',1,'#f4c430',INK,26));
   if(li>=1){const k=K(li,1,'tin');for(let i=0;i<26;i++){const x=30+i*48,y=700-Math.abs(Math.sin(t*5+i))*16*k;fill('rgba(244,196,48,.9)',()=>circ(x,y-30,8),0);line([[x,y-22],[x,y]],'#ddd',3)}hand("A'TIN",1180,600,34,'#f4c430')}
   withA(vis(li,2,'twenty',2),()=>stamp('2021',1080,620,1,'#f4c430'))});}},

{chap:'Bigger stages',lines:[
 'Then came bigger songs like Alab and What?, and arenas glowing with lightsticks.',
 'So how did SB19 become stars? Not overnight. About three years of late nights.'],
 draw(t,li){PL(t,.3,()=>arena(t));
  PL(t,1,()=>{[260,450,640,830,1020].forEach((x,i)=>dancer(x,330,.85,t,i,{dance:li===0,cheer:li===1&&since('overnight')>=0}));
   tag(420,90,'ALAB',vis(li,0,'alab',0),'#e63946','#fff',30);tag(860,90,'WHAT?',vis(li,0,'what',0),'#3a6fd8','#fff',30);
   if(li===1)withA(K(li,1,'overnight'),()=>clock(640,520,t,2));
   if(li===1&&since('late')>=0){const a=SM(clamp01((since('late')-.3)/1.6));c.save();c.globalAlpha=a;titleCard(t);c.restore()}});}}
];

const SHOTS={'4.1':['push',1.2,640,330]};
S.forEach((sc,si)=>{const base=sc.draw;sc.draw=function(t,li){const key=si+'.'+li,sp=SHOTS[key];
  const isCur=window.CL&&window.CL.s===si,savedCL=window.CL;if(window.CL&&!isCur)window.CL={s:si,l:li,lt:99};const L=isCur?lt():99;
  let z=1,cx=W/2,cy=H/2;if(sp){cx=sp[2];cy=sp[3];const dl=(window.TL||[]).find(x=>x[0]===si&&x[1]===li);const D=dl?dl[3]-dl[2]:4;z=1+(sp[1]-1)*(SM(clamp01(L/1.4))-SM(clamp01((L-D+.2)/1.4)))}
  c.save();if(z!==1){c.translate(W/2,H/2);c.scale(z,z);c.translate(-cx,-cy)}
  base.call(this,t,li);c.restore();
  if(si>=1&&li===0&&t<7.6)onAir(sc.chap,clamp01((t-4.2)/.6)*clamp01((7.6-t)/.7),t);
  window.CL=savedCL}});
window.since=function(word){const k=window.CL;if(!k)return 99;const Lw=(WORDS[k.s]||{})[k.l]||[];const w=word.toLowerCase();const hit=Lw.find(x=>x[0]===w||x[0].startsWith(w));if(!hit)return -1;
 let g=Math.floor(hit[1]/1.8)*1.8;const rw=(window.TL||[]).find(x=>x[0]===k.s&&x[1]===k.l);if(rw)g=Math.min(g,Math.max(0,(rw[3]-rw[2])-2.5));const d=k.lt-g;return d>=0?d:-1};
window.FONTS=Promise.all(["700 40px Caveat","900 40px Fredoka","700 40px Fredoka","700 25px Nunito"].map(f=>document.fonts.load(f)));
</script>
