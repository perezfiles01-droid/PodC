const {chromium}=require('playwright');const fs=require('fs');const [page,kind,out]=process.argv.slice(2);
(async()=>{const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});const p=await b.newPage({viewport:{width:1300,height:800}});
await p.addInitScript(()=>{window.requestAnimationFrame=()=>0});await p.goto('file://'+page);await p.waitForTimeout(1000);await p.evaluate(()=>FONTS);
const d=await p.evaluate(k=>{const t=5.3;c.setTransform(1,0,0,1,0,0);window.CL=null;let L;
 if(k==='sb19'){practiceRoom(t);clock(1180,120,t,2);[700,820,940,1060,1180].forEach((x,i)=>dancer(x,660,1.15,t,i,{dance:true,sweat:true}));mop(620,640,.9,t,{dance:true,puddle:true});L=[['FROM 2 AM',0,'#fff6dc'],['PRACTICE',100,'#f4c430'],['TO BILLBOARD',200,'#ff5a6e']]}
 else{garden(t,true);[600,720,840,960,1080,1200].forEach((x,i)=>girl(x,640,1.05,t,i,{dance:true}));bud(470,700,1.2,t,1);L=[['HOW BINI',0,'#fff6dc'],['BLOOMED',100,'#f28fb1'],['INTO STARS',200,'#f4c430']]}
 c.save();c.translate(50,120);c.rotate(-.04);c.font='900 92px Fredoka,sans-serif';c.lineJoin='round';L.forEach(([w,y,col])=>{c.lineWidth=20;c.strokeStyle='#15131f';c.strokeText(w,0,y);c.fillStyle=col;c.fillText(w,0,y)});c.restore();
 c.save();c.translate(56,420);c.font='700 38px Fredoka,sans-serif';c.lineWidth=8;c.strokeStyle='#15110d';c.strokeText('Papel Tales',0,0);c.fillStyle='#fff';c.fillText('Papel Tales',0,0);c.restore();
 c.fillStyle=c.createPattern(grain,'repeat');c.fillRect(0,0,W,H);return cv.toDataURL('image/jpeg',.92)},kind);
fs.writeFileSync(out,Buffer.from(d.split(',')[1],'base64'));await b.close()})();
