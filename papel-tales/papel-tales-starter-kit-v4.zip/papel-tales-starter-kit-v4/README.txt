PAPEL TALES STARTER KIT
=======================
Everything needed to make another narrated paper-cut story video the same way as
"Mabuhay ang Fiesta" and "Were You Here Before?", and upload it to the
Papel Tales YouTube channel.

paper-story-video-instructions.txt  The full recipe, standing rules, and every fix learned.
examples/fiesta.html                Finished story page: paper helpers, characters
                                    (carabao, tarsier, people, church, banderitas, fireworks...).
examples/reincarnation.html         Finished story page: tortoise, fox, ghosts, wheel, map...
examples/fiesta-voiceover-script.txt Script format + pronunciation guide format.
scripts/lines.js     Pull narration lines out of a story page.
scripts/tts4.py      Kokoro narration: EVERY word checked (fil.json, heteronyms.py rules, CMU dictionary);
                     stops if any word is uncertain. pip install cmudict. (tts3.py kept for reference)
scripts/heteronyms.py Context rules for live/lives, wind, record, read... Add a rule for any misread word.
scripts/fil.json     Pronunciation list (IPA) for Filipino words and names.
scripts/audio.py     Timeline + festive music + mix.
scripts/render1440.js 1440p renderer: smooth crossfades, moving camera, framed subtitles.
scripts/beats.js     since('word') / popIn() / after(): make visuals appear on the exact spoken word.
scripts/render1440-beats.js  1440p renderer with word timing (reads words.json from tts4.py).
                     Usage: node render1440-beats.js page.html [t1,t2 preview] [out.mp4]
scripts/thumb.js     Thumbnail maker (1280x720).

READ paper-story-video-instructions.txt UPDATES v6 to v16 first (v15 and v16 override older pacing/motion counts) (and v8: motion every 1-2 s, visuals on every phrase) (standing rules: new characters
every story, mixed styles, every-word pronunciation, US reach).
examples/batang90s.html  LATEST reference: no narrator characters, word-timed beats, comic kids.
examples/aswang.html  Mixed-style story page (cardboard, crayon, watercolour, silhouettes, wood, grit).
ANIMATION-TOOLKIT.md  Free tools to add next (Remotion, GSAP, rough.js...).

Order: write story page -> lines.js -> tts4.py (resolve pronunciation_issues.txt) -> audio.py -> preview frames ->
render1440.js -> two-pass compress to ~95 MB -> thumbnail -> GitHub -> YouTube (Public).
Paths inside the scripts point at ../voice and ../lib; adjust to where you run them.


PUBLISHED SO FAR (channel Papel Tales, @PapelTales, ID UCDiyA1pjIBmJHpatJ9OJg5Q)
- The Aswang: The Philippine Vampire Legend Explained   https://www.youtube.com/watch?v=d3X4L1xTQMg
- Batang 90s: Why Filipinos Miss the 1990s So Much       https://www.youtube.com/watch?v=aPIUd9lEnnY
Files: github.com/perezfiles01-droid/Jim, branch ccr-eac3bebd-9j4haa, folder papel-tales/

v4 additions (11 Oct 2026)
examples/kdrama.html            LATEST reference: K-Drama Fever (new sets, sticker toons, layered depth, theme layer).
examples/kdrama-theme-layer.js  Episode cards, VHS, letterbox, panels, crossfade-safe wrapper, phrase-paced beats.
scripts/sfx.py                  Optional 2-3 soft sound effects on the biggest jokes only.
scripts/audio.py                Narration starts at 4.6 s so the title card plays alone.
- The Aswang ... / Batang 90s ... / K-Drama Fever v3: https://www.youtube.com/watch?v=VsbCtAQyvAQ
