
/* v16: fewer elements - keep only what the story needs */
const HIDE_HAND=new Set(['poster','...seriously?','!?','?','bow','mano','share!','streaming','la la la','piggyback!','refill!','ouch!','busted','border','sniff...','not crying!','...','bye!','about 2 months','...still riding','together','friends text...','the biggest reason...','zoom!','sparkle','♪','*wrist grab*','music','plot twist!']);
const KEEP_BOOM=new Set(['AJA!','KYAAA!','NO SPOILERS!','+350%','TWINS?!','K-DRAMA','SAME!']);
{const _h=hand;window.hand=function(s,...a){if(HIDE_HAND.has(s))return;return _h(s,...a)};const _b=boom;window.boom=function(x,y,r,txt2,...a){if(!KEEP_BOOM.has(txt2))return;return _b(x,y,r,txt2,...a)};window.sparkle=function(){};}

/* ================= v13: K-DRAMA THEME LAYER + SHOT PLAN ================= */
const EASE=x=>x<=0?0:x>=1?1:1-Math.pow(1-x,3);
function speedLines(cx,cy,a=.6,t=0){c.save();c.globalAlpha=a;c.strokeStyle='#fffdf4';for(let i=0;i<48;i++){const an=i/48*Math.PI*2+hr(i)*.1,r0=260+hr(i*3+Math.floor(t*12))*120;c.lineWidth=2+hr(i*7)*6;c.beginPath();c.moveTo(cx+Math.cos(an)*r0,cy+Math.sin(an)*r0);c.lineTo(cx+Math.cos(an)*1200,cy+Math.sin(an)*1200);c.stroke()}c.restore()}
function letterbox(a=1){c.save();c.globalAlpha=a;c.fillStyle='#0b0a12';c.fillRect(-200,-200,W+400,262);c.fillRect(-200,H-62,W+400,262);c.restore()}
function bokeh(t,n=18){c.save();c.globalCompositeOperation='lighter';for(let i=0;i<n;i++){const x=(hr(i)*W+Math.sin(t*.3+i)*40),y=(hr(i*5)*H+Math.cos(t*.25+i)*30),r=20+hr(i*9)*50;const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(255,${190+hr(i)*60|0},${200+hr(i*2)*55|0},.22)`);g.addColorStop(1,'rgba(255,200,220,0)');c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2)}c.restore()}
function vhs(t,label){c.save();c.fillStyle='rgba(255,230,180,.10)';c.fillRect(-200,-200,W+400,H+400);c.fillStyle='rgba(0,0,0,.10)';for(let y=0;y<H;y+=4)c.fillRect(0,y,W,1.5);
 const ty=(t*140)%(H+200)-100;c.fillStyle='rgba(255,255,255,.12)';c.fillRect(0,ty,W,10);c.fillStyle='rgba(255,255,255,.06)';c.fillRect(0,ty+14,W,4);
 c.font='700 30px "Courier New",monospace';c.fillStyle='#fffdf4';c.fillText('▶ PLAY',90,110);if(Math.sin(t*4)>0){c.fillStyle='#ff4a4a';c.beginPath();c.arc(W-250,100,9,0,7);c.fill()}c.fillStyle='#fffdf4';c.fillText(label,W-230,110);c.restore()}
function sepia(a){c.save();c.globalCompositeOperation='color';c.globalAlpha=a;c.fillStyle='#a07850';c.fillRect(-200,-200,W+400,H+400);c.restore()}
function epCard(n,title,t,a){if(a<=0)return;c.save();c.globalAlpha=a;c.fillStyle='rgba(10,8,20,.35)';c.fillRect(-200,H-250,W+400,190);
 c.font='italic 700 34px Georgia,serif';c.fillStyle='#ffd6e4';c.fillText('EP. '+n,110,H-170);c.font='700 58px Georgia,serif';c.fillStyle='#fffdf4';c.fillText(title,110,H-108);
 c.strokeStyle='#ffd6e4';c.lineWidth=2;c.beginPath();c.moveTo(110,H-155);c.lineTo(110+Math.min(1,a*1.4)*420,H-155);c.stroke();sparkle(560,H-178,14,t);c.restore()}
function panelGrid(rects,fns,bg='#fffdf4'){c.save();c.fillStyle=bg;c.fillRect(-200,-200,W+400,H+400);rects.forEach(([x,y,w,h],i)=>{c.save();sh(true,8);c.fillStyle='#000';c.fillRect(x,y,w,h);sh(false);c.beginPath();c.rect(x,y,w,h);c.clip();fns[i](x,y,w,h);c.restore();c.save();c.strokeStyle=DK;c.lineWidth=5;c.strokeRect(x,y,w,h);c.restore()});c.restore()}
function halftone(x,y,w,h,col,dot='rgba(255,255,255,.35)'){c.fillStyle=col;c.fillRect(x,y,w,h);c.fillStyle=dot;for(let j=0;j<h;j+=16)for(let i=0;i<w;i+=16){c.beginPath();c.arc(x+i+(j/16%2)*8,y+j,2.6,0,7);c.fill()}}
function headShot(cx,cy,s,t,o){toon(cx,cy+176*s,s,t,o)}  // place a toon so its face centre lands on (cx,cy)
function toBeContinued(a,t){if(a<=0)return;sepia(.75*a);c.save();c.globalAlpha=a;const x=W-560+(1-EASE(a))*300;stk('#c9a24a',()=>{c.moveTo(x,H-170);c.lineTo(x+380,H-170);c.lineTo(x+380,H-200);c.lineTo(x+460,H-140);c.lineTo(x+380,H-80);c.lineTo(x+380,H-110);c.lineTo(x,H-110);c.closePath()},3,8);c.font='900 34px Georgia,serif';c.fillStyle=DK;c.fillText('To be continued...',x+30,H-128);c.restore()}

/* ---- custom shots that replace a line's set ---- */
const CUSTOM={
 '1.2':(t)=>{/* manhwa panels: everyone sobbing at Endless Love */
  panelGrid([[40,40,520,640],[590,40,320,310],[930,40,310,310],[590,370,320,310],[930,370,310,310]],[
   (x,y,w,h)=>{halftone(x,y,w,h,'#f6d0a0','rgba(200,90,40,.18)');leafFall(t,10);crtTV(x+w/2+10,y+300,1.2,(cx,cy)=>{fill('#f6d0a0',()=>c.rect(cx-100,cy-90,200,180),0);heartS(cx,cy,2.2,ROSE)});
    if(since('endless')>=0)at(x+w/2,y+90,B('endless'),()=>{stk('#fffdf4',()=>rr(-220,-50,440,100,14),2.6,8);hand('Endless Love',0,-2,46,'#c0262d');hand('Autumn in My Heart',0,34,26,DK)});
    stamp('2004',x+150,y+560,B('four'));stamp('2006',x+380,y+560,B('six'))},
   (x,y,w,h)=>{halftone(x,y,w,h,'#bfe3f5');headShot(x+w/2,y+h/2+10,1.9,t,M(LOLA,{mouth:since('cried')>=0?'cry':'o',brow:'sad'}));if(since('hit')>=0)hand('sniff...',x+70,y+50,30,DK)},
   (x,y,w,h)=>{halftone(x,y,w,h,'#ffd6e4');headShot(x+w/2,y+h/2+10,1.9,t+1,M(TITO,{mouth:since('cried')>=0?'cry':'flat',brow:'sad'}));if(since('cried')>=0)hand('not crying!',x+w/2,y+50,30,DK)},
   (x,y,w,h)=>{halftone(x,y,w,h,'#e2d4f2');headShot(x+w/2,y+h/2+10,1.9,t+2,M(NENE,{mouth:since('cried')>=0?'cry':'o',brow:'sad',pop:true}))},
   (x,y,w,h)=>{halftone(x,y,w,h,'#d4f0e6');tissueBox(x+w/2,y+h/2+60,1.6,since('cried')>=0?clamp01(1-since('cried')/2):.9,t);if(since('cried')>=0)boom(x+w/2,y+80,44,'WAAAH',B('cried'),'#fffdf4','#1f6fb2')}])},
 '2.3':(t)=>{/* top-down shot of the family table */
  patt('#a0683a',()=>c.rect(-200,-200,W+400,H+400),2,'rgba(60,30,10,.18)',0);stk('#f3e2c6',()=>ell(640,380,520,280),2.6,10);
  if(since('big')>=0)at(640,120,B('big'),()=>{stk('#c8a46a',()=>rr(-230,-60,460,120,10),2.4,6);[LOLA,TITO,MAE,NENE,BOY].forEach((o,i)=>headShot(-170+i*85,0,.55,t+i,M(o,{mouth:'grin'})))});
  const plates=[['#fff','rice',470,330],['#e8743b','kimchi',810,330],['#6a3a1a','adobo',470,470],['#f4c430','pancit',810,470]];
  plates.forEach(([col,lab,x,y],i)=>{const k=since('food')>=0?clamp01((since('food')-i*.22)/.4):(since('lots')>=0?1:0);at(x,y,EASE(k)*1.0001,()=>{stk('#fdfbf4',()=>circ(0,0,74),2.4,6);stk(col,()=>circ(0,0,52),2,0);if(lab==='pancit')for(let j=0;j<8;j++)line([[-40,-20+j*6],[40,-24+j*6+Math.sin(j)*4]],'#c89a2a',3);if(lab==='rice')for(let j=0;j<14;j++)fill('#efe8d8',()=>ell(-30+hr(j)*60,-30+hr(j*3)*60,5,3,hr(j)),0);hand(lab,0,104,30,'#fffdf4')})});
  if(since('grandmothers')>=0){const r=EASE(clamp01(since('grandmothers')/.6));c.save();c.translate(120+r*170,700-r*240);c.rotate(-.6);stk('#c99a6e',()=>rr(-26,0,52,220,26),2.4,6);stk('#9aa0b0',()=>{rr(-6,-90,12,100,6);ell(0,-100,30,20)},2,4);c.restore();bub(250,170,260,70,'Kain pa, apo!',32)}
  if(since('strict')>=0){const r=EASE(clamp01(since('strict')/.5));c.save();c.translate(W-80-r*150,720-r*250);c.rotate(.7);stk('#b97f52',()=>rr(-26,0,52,220,26),2.4,6);stk('#b97f52',()=>rr(-8,-60,16,64,8),2.2,4);c.restore();bub(1030,170,330,70,'No phones at the table!',30,undefined,-1)}
  if(since('lots')>=0){const k=since('lots');phone(640+Math.sin(t*20)*3,380,.9,()=>heartS(0,0,1.2,ROSE),.4);if(k>.6)hand('busted',640,280,30,DK)}},
 '4.2':(t)=>{/* over-the-shoulder: viewers from behind, the drama on the big screen */
  linedSky('#1a1430','#2a2050');glow(640,300,520,'190,170,255',.35);
  stk('#fffdf4',()=>rr(190,60,900,440,14),3,10);c.save();c.beginPath();c.rect(205,75,870,410);c.clip();linedSky('#f7d6e4','#e7dcf7',75,485);petals(t,18);
   toon(560,470,1.05,t,M(MAE,{top:'#fff',mouth:'o',look:.8}));c.save();c.translate(720,470);toon(0,0,1.15,t,M(BOY,{top:'#2a2a44',face:-1,look:-.8,mouth:'smirk',pose:'point'}));c.restore();
   stk('#e0a877',()=>{rr(600,330,70,22,10)},2,4);hand('*wrist grab*',640,140,40,'#8a5ab0');sparkle(470,180,18,t);sparkle(820,220,14,-t);c.restore();
  const sc=since('scream')>=0;for(let i=0;i<5;i++){const x=180+i*230,jump=sc?Math.abs(Math.sin(t*8+i))*30:Math.sin(t*2+i)*3,y=640-jump;
   fill('#0d0a18',()=>{ell(x,y,70,80);rr(x-110,y+50,220,200,60)},0);if(i%2===0)fill('#0d0a18',()=>{circ(x,y-82,26)},0);
   if(since('pillows')>=0&&i!==4)stk('#fffdf4',()=>rr(x-60,y+40,120,70,26),2.2,5)}
  if(sc)boom(320,560,58,'KYAAA!',B('scream'),PINK,'#fff');
  const n=since('tissue')<0?.4:(since('again')>.5?clamp01((since('again')-.5)/.8):.05);tissueBox(1110,620,1.4,n,t);
  if(since('again')>=.5){const p=EASE(clamp01((since('again')-.5)/.8));stk('#e0a877',()=>rr(1340-p*160,520,160,40,20),2.2,5);hand('refill!',1110,450,40,'#fffdf4')}},
 '8.2':(t)=>{/* three manhwa panels: mother & daughter / the chat / the spoiler panic */
  panelGrid([[40,40,400,640],[460,40,380,640],[860,40,380,640]],[
   (x,y,w,h)=>{halftone(x,y,w,h,'#ffd6e4');rain(t,30);if(since('mothers')>=0){umbrella(x+w/2,y+180,1.2,PINK,t);toon(x+w/2-55,y+600,1.05,t,{hair:'long',hairC:'#2a1d24',top:'#f28fb1',bot:'#7a5a6a',skirt:true,pose:'phone',mouth:'grin',skin:'#d8a070'});toon(x+w/2+60,y+600,.85,t,M(NENE,{pose:'phone',mouth:'grin',face:-1}));hand('together',x+w/2,y+70,40,DK)}},
   (x,y,w,h)=>{halftone(x,y,w,h,'#d8ecff');phone(x+w/2,y+h/2,3.6,()=>{fill('#f6f2e6',()=>c.rect(-30,-54,60,104),0);if(since('reached')>=0){stk('#bfe6c0',()=>rr(-26,-40,40,18,6),.8,0);hand('ep 10 na?',-6,-27,7,DK)}if(since("don't")>=0){stk('#ffd6e4',()=>rr(-12,-10,38,26,6),.8,0);hand("DON'T",7,0,7,ROSE);hand('TELL ME!',7,10,6,ROSE)}});if(since('friends')>=0)hand('friends text...',x+w/2,y+70,38,DK)},
   (x,y,w,h)=>{halftone(x,y,w,h,'#fff1b8');const d=since("don't");headShot(x+w/2,y+h/2+40,2.6,t,M(MAE,{mouth:d>=0?'o':'smile',pop:d>=0,brow:d>=0?'angry':undefined}));
    if(d>=0){speedLines(x+w/2,y+h/2,.5,t);stk('#e0a877',()=>{circ(x+60,y+h/2+20,30);circ(x+w-60,y+h/2+20,30)},2.2,5);boom(x+w/2,y+120,52,'NO SPOILERS!',B("don't"),PINK,'#fff');hand('la la la',x+w/2,y+h-60,36,DK)}}])}
};
/* ---- shot plan: [type, zoom, cx, cy, word] per line; theme per scene ---- */
const SHOTS={};
const LAYOUT_CHANGE={'6.3':1,'8.3':1};
S.forEach((sc,si)=>{const base=sc.draw;sc.draw=function(t,li){const key=si+'.'+li,sp=SHOTS[key];
  const isCur=window.CL&&window.CL.s===si,savedCL=window.CL;if(window.CL&&!isCur)window.CL={s:si,l:li,lt:99};const L=isCur?lt():99;
  let z=1,cx=W/2,cy=H/2,speed=0;
  if(sp&&sp[0]!=='wide'){cx=sp[2];cy=sp[3];if(sp[0]==='push')z=1+(sp[1]-1)*EASE(L/.9);if(sp[0]==='pull')z=sp[1]-(sp[1]-1)*EASE(L/2.5);if(sp[0]==='snap'){const d=since(sp[4]);if(d>=0){z=1+(sp[1]-1)*EASE(d/.25);speed=clamp01(1-d/1.4)}}}
  c.save();if(z!==1){c.translate(W/2,H/2);c.scale(z,z);c.translate(-cx,-cy)}
  const drawLine=(l)=>{const k2=si+'.'+l;if(CUSTOM[k2])CUSTOM[k2](t);else base.call(this,t,l)};
  drawLine(li);c.restore();
  const prevKey=si+'.'+(li-1),chg=li>0&&(CUSTOM[key]||CUSTOM[prevKey]||LAYOUT_CHANGE[key]);
  if(isCur&&chg&&L<1.0){const sv=window.CL;window.CL={s:si,l:li-1,lt:99};c.save();c.globalAlpha=1-EASE(L/1.0);drawLine(li-1);c.restore();window.CL=sv}
  if(speed>0)speedLines(W/2,H/2,.55*speed,t);
  // theme layers
  if(si===1&&!CUSTOM[key])vhs(t,'2003');
  if(si===4){bokeh(t);letterbox(1);if(li===0)hand('♪ OST',W-180,H-20,30,'#ffd6e4')}
  if(si===8&&li===3){const d=since('name');toBeContinued(d>=0?clamp01((d-.6)/.5):0,t)}
  if(si>=1&&li===0&&t<7.2)epCard(si,sc.chap,t,clamp01((t-4.3)/.5)*clamp01((7.2-t)/.6));
  window.CL=savedCL}});

window.since=function(word){const k=window.CL;if(!k)return 99;const Lw=(WORDS[k.s]||{})[k.l]||[];const w=word.toLowerCase();const hit=Lw.find(x=>x[0]===w||x[0].startsWith(w));if(!hit)return -1;
 const g=Math.floor(hit[1]/1.8)*1.8;const d=k.lt-g;return d>=0?d:-1};
window.B=function(word,dur=.8){const d=since(word);if(d<0)return 0;const p=Math.min(1,d/Math.max(dur,.8));return p>=1?1:1-Math.pow(1-p,3)};
