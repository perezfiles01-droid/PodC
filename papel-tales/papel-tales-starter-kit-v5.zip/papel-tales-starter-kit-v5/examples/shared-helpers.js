
/* ================= K-DRAMA FEVER: new sets, sticker characters, layered depth (v12) ================= */
const PINK='#f28fb1',ROSE='#e63946',LAV='#b9a3e3',CREAM='#fff6dc',DK='#1d1a2e',GOLD='#f4c430',TEAL='#2bb3a3',SKY='#7fd3f0';
/* ---- sticker drawing: white cut edge + dark ink line ---- */
function stk(col,fn,lw=2.4,edge=8){c.save();sh(true,6);c.lineJoin='round';c.lineCap='round';if(edge>0){c.strokeStyle='#fffdf7';c.lineWidth=edge;c.beginPath();fn();c.stroke()}sh(false);c.fillStyle=col;c.beginPath();fn();c.fill();c.strokeStyle=DK;c.lineWidth=lw;c.beginPath();fn();c.stroke();c.restore()}
function line(pts,col=DK,w=3){c.save();c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.stroke();c.restore()}
/* ---- paper textures ---- */
function linedSky(a,b,y0=0,y1=H){const g=c.createLinearGradient(0,y0,0,y1);g.addColorStop(0,a);g.addColorStop(1,b);c.fillStyle=g;c.fillRect(-120,y0-60,W+240,y1-y0+60);c.save();c.strokeStyle='rgba(90,120,200,.18)';c.lineWidth=1.5;for(let y=y0+30;y<y1;y+=26){c.beginPath();c.moveTo(-120,y);c.lineTo(W+120,y);c.stroke()}c.strokeStyle='rgba(220,60,80,.22)';c.beginPath();c.moveTo(90,y0-60);c.lineTo(90,y1);c.stroke();c.restore()}
function news(col,fn,seed=1,a=.22){c.save();sh(true,6);c.fillStyle=col;c.beginPath();fn();c.fill();sh(false);c.clip();c.fillStyle=`rgba(40,30,30,${a})`;
 for(let y=-60;y<H+60;y+=11){let x=-120+(hr(seed+y)*40);while(x<W+120){const w=8+hr(seed*3+x*.1+y)*34;c.fillRect(x,y,w,4);x+=w+5}}
 c.fillStyle=`rgba(40,30,30,${a*1.4})`;for(let i=0;i<6;i++)c.fillRect(hr(seed+i)*W,hr(seed*2+i)*H,120+hr(i)*100,14);c.restore()}
function patt(col,fn,kind=0,col2='rgba(255,255,255,.35)',d=6){c.save();sh(true,d);c.fillStyle=col;c.beginPath();fn();c.fill();sh(false);c.clip();c.strokeStyle=col2;c.fillStyle=col2;c.lineWidth=3;
 if(kind===0){for(let y=-60;y<H+60;y+=22){c.beginPath();for(let x=-120;x<W+120;x+=22)c.lineTo(x,y+(Math.round(x/22)%2?10:0));c.stroke()}}
 if(kind===1){for(let y=-60;y<H+60;y+=24)for(let x=-120;x<W+120;x+=24)c.fillRect(x+(Math.round(y/24)%2)*12,y,5,5)}
 if(kind===2){for(let x=-H-120;x<W+120;x+=18){c.beginPath();c.moveTo(x,-60);c.lineTo(x+H,H+60);c.stroke()}}
 if(kind===3){for(let y=-60;y<H+60;y+=30)for(let x=-120;x<W+120;x+=30){c.beginPath();c.arc(x+(Math.round(y/30)%2)*15,y,6,0,7);c.stroke()}}
 c.restore()}
function facet(pts,colA,colB,d=6){c.save();sh(true,d);c.fillStyle=colA;c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.fill();sh(false);c.clip();
 for(let i=1;i<pts.length-2;i+=2){c.fillStyle=colB;c.beginPath();c.moveTo(pts[i][0],pts[i][1]);c.lineTo(pts[i+1][0],pts[i+1][1]);c.lineTo(pts[i+1][0],H+60);c.lineTo(pts[i][0]+20,H+60);c.fill()}c.restore()}
function mountains(y,colA,colB,seed,amp=180,d=4){const P=[[-160,H+60]];for(let i=0;i<=16;i++){const x=-160+i*(W+320)/16;P.push([x,y-(i%2?amp*(.5+hr(seed+i)*.5):amp*.15*hr(seed*2+i))])}P.push([W+160,H+60]);facet(P,colA,colB,d)}
function haze(y,a=.35){const g=c.createLinearGradient(0,y-120,0,y+60);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(1,`rgba(255,250,240,${a})`);c.fillStyle=g;c.fillRect(-120,y-120,W+240,180)}
function rays(x,y,col='255,240,190',n=7,len=900,a=.18,t=0){c.save();c.globalCompositeOperation='lighter';for(let i=0;i<n;i++){const an=Math.PI*.25+i/(n-1)*Math.PI*.5+Math.sin(t*.3+i)*.02,w=.05+hr(i)*.04;c.fillStyle=`rgba(${col},${a*(.6+.4*Math.sin(t+i))})`;c.beginPath();c.moveTo(x,y);c.lineTo(x+Math.cos(an-w)*len,y+Math.sin(an-w)*len);c.lineTo(x+Math.cos(an+w)*len,y+Math.sin(an+w)*len);c.fill()}c.restore()}
function glow(x,y,r,col='255,220,150',a=.5){c.save();c.globalCompositeOperation='lighter';const g=c.createRadialGradient(x,y,4,x,y,r);g.addColorStop(0,`rgba(${col},${a})`);g.addColorStop(1,`rgba(${col},0)`);c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);c.restore()}
// parallax layer: rate 0.2 far ... 1.6 near (offsets relative to the scene's own clock)
function PL(t,rate,fn){const k=Math.min(t-4,30);c.save();c.translate(-k*3*rate+Math.sin(t*.25)*10*rate,Math.sin(t*.2)*3*rate);fn();c.restore()}
function nearLeaves(t,col='#16122a'){const sw=Math.sin(t*1.1)*.05;[[-40,H+30,1],[W+120,H+30,-1]].forEach(([x,y,f],k)=>{c.save();c.translate(x,y);c.scale(f,1);c.rotate(sw*(k?-1:1));for(let i=0;i<6;i++){c.save();c.rotate(-1.4+i*.28);fill(col,()=>{c.moveTo(0,0);c.quadraticCurveTo(60,-40,0,-260-hr(i+k)*80);c.quadraticCurveTo(-50,-60,0,0)},0);c.restore()}c.restore()})}
function bunting(y,t,cols=['#f28fb1','#f4c430','#2bb3a3','#b9a3e3']){line([[-120,y],[W/2,y+46],[W+120,y]],DK,2);for(let i=0;i<22;i++){const x=-100+i*70,yy=y+Math.sin(clamp01((x+120)/(W+240))*Math.PI)*45+2,sw=Math.sin(t*2+i)*.1;c.save();c.translate(x,yy);c.rotate(sw);stk(cols[i%cols.length],()=>{c.moveTo(-20,0);c.lineTo(20,0);c.lineTo(0,34);c.closePath()},1.5,4);c.restore()}}
/* ---- NEW character design: big-head sticker toons ---- */
function toon(x,y,s,t,o={}){const skin=o.skin||'#e0a877',hairC=o.hairC||'#2a1d24',top=o.top||PINK,bot=o.bot||'#4a4a8a',pose=o.pose||'stand',mouth=o.mouth||'smile',f=o.face||1,look=o.look===undefined?.3:o.look;
 const br=Math.sin(t*2.2+x*.01)*1.5,ph=t*8+x*.03;let la=.25,ra=-.25,ll=0,rl=0,lift=0;const sit=pose==='sit';
 if(pose==='wave'){ra=-2.7+Math.sin(t*9)*.35} if(pose==='cheer'){la=2.7;ra=-2.7+Math.sin(t*9)*.2;lift=Math.abs(Math.sin(t*7))*14} if(pose==='point'){ra=-1.5}
 if(pose==='walk'){ll=Math.sin(ph)*.45;rl=-ll;la=-ll*.8+.15;ra=ll*.8-.15} if(pose==='jump'){lift=Math.abs(Math.sin(t*5))*40;la=2.4;ra=-2.4;ll=.5;rl=-.5} if(pose==='phone'){ra=-2.1;la=1.9}
 if(pose==='hug'){ra=-1.2;la=1.2}
 c.save();c.translate(x,y-lift*s);c.scale(s*f,s);
 const limb=(px,py,a,len,col,w)=>{c.save();c.translate(px,py);c.rotate(a);stk(col,()=>rr(-w/2,0,w,len,w/2),2.2,6);c.restore()};
 if(sit){stk(bot,()=>rr(-26,-62,70,26,12),2.2,6);limb(30,-46,-.1,40,skin,13);limb(14,-46,-.1,40,skin,13)}
 else{limb(-12,-62,ll,58,bot,16);limb(12,-62,rl,58,bot,16);[[-12,ll],[12,rl]].forEach(([px,a])=>{c.save();c.translate(px,-62);c.rotate(a);stk(o.shoe||'#f6f2e6',()=>ell(4,60,13,7),2,5);c.restore()})}
 if(o.skirt)stk(bot,()=>{c.moveTo(-30,-58);c.lineTo(30,-58);c.lineTo(22,-86);c.lineTo(-22,-86);c.closePath()},2.2,6);
 const hs=o.hs||1,hy=-176+br*1.4;
 if(o.hair==='long')stk(hairC,()=>rr(-40,hy-30,80,96,30),2.2,6);
 if(o.hair==='pony')stk(hairC,()=>ell(40,hy+10,14,36,.4),2.2,6);
 limb(-24,-128+br,la,50,top,13);limb(24,-128+br,ra,50,top,13);
 stk(top,()=>{c.moveTo(-28,-130+br);c.quadraticCurveTo(0,-140+br,28,-130+br);c.lineTo(24,-60);c.quadraticCurveTo(0,-54,-24,-60);c.closePath()},2.4,8);
 if(o.tie)stk(ROSE,()=>{c.moveTo(-4,-126);c.lineTo(4,-126);c.lineTo(6,-96);c.lineTo(0,-90);c.lineTo(-6,-96);c.closePath()},1.5,3);
 [[-24,la],[24,ra]].forEach(([px,a])=>{c.save();c.translate(px,-128+br);c.rotate(a);stk(skin,()=>circ(0,52,8),1.8,4);c.restore()});
 stk(skin,()=>ell(0,hy,38,40),2.6,9);stk(skin,()=>{ell(-37,hy+4,8,11);ell(37,hy+4,8,11)},1.8,4);
 const HS={short:()=>{c.moveTo(-40,hy-2);c.quadraticCurveTo(-42,hy-50,0,hy-46);c.quadraticCurveTo(42,hy-50,40,hy-2);c.quadraticCurveTo(20,hy-30,-40,hy-2)},
  long:()=>{c.moveTo(-41,hy+10);c.quadraticCurveTo(-44,hy-52,0,hy-46);c.quadraticCurveTo(44,hy-52,41,hy+10);c.quadraticCurveTo(30,hy-24,6,hy-26);c.quadraticCurveTo(-24,hy-20,-41,hy+10)},
  pony:()=>{c.moveTo(-40,hy);c.quadraticCurveTo(-42,hy-50,0,hy-46);c.quadraticCurveTo(42,hy-50,40,hy);c.quadraticCurveTo(10,hy-28,-40,hy)},
  bun:()=>{c.moveTo(-40,hy-4);c.quadraticCurveTo(-40,hy-46,0,hy-44);c.quadraticCurveTo(40,hy-46,40,hy-4);c.quadraticCurveTo(0,hy-30,-40,hy-4);circ(0,hy-54,16)},
  spiky:()=>{c.moveTo(-40,hy-4);for(let i=0;i<7;i++){const a=Math.PI+i/6*Math.PI;c.lineTo(Math.cos(a)*(44+(i%2)*14),hy-8+Math.sin(a)*(44+(i%2)*14))}c.lineTo(40,hy-4);c.quadraticCurveTo(0,hy-28,-40,hy-4)},
  bald:()=>{c.moveTo(-40,hy+4);c.quadraticCurveTo(-44,hy-24,-30,hy-26);c.lineTo(-26,hy-8);c.closePath();c.moveTo(40,hy+4);c.quadraticCurveTo(44,hy-24,30,hy-26);c.lineTo(26,hy-8);c.closePath()}};
 stk(hairC,HS[o.hair||'short'],2.2,5);
 const ey=hy-2,pop=o.pop?1.5:1,er=9*pop;if(window.EYESTYLE==='anime'){const ea=11*pop,bl=Math.sin(t*.7+x)>.985?.12:1;[-15,15].forEach(dx=>{stk('#ffffff',()=>ell(dx,ey,ea,ea*1.35*bl),2,0);if(bl>.5){fill(o.iris||'#5a4a9a',()=>ell(dx+look*4,ey+2,ea*.66,ea*.86),0);fill(DK,()=>ell(dx+look*4,ey+3,ea*.3,ea*.42),0);fill('#fff',()=>{circ(dx+look*4+3,ey-3,ea*.24);circ(dx+look*4-2,ey+5,ea*.12)},0)}line([[dx-ea-1,ey-ea*1.25],[dx+ea+1,ey-ea*1.4]],DK,3.4)})}else{[-14,14].forEach(dx=>{stk('#ffffff',()=>ell(dx,ey,er,er*1.15),2,0);fill(DK,()=>circ(dx+look*4,ey+1,4.5*pop),0);fill('#fff',()=>circ(dx+look*4+1.5,ey-1.5,1.6),0)})}
 if(o.brow!==false){const b=o.brow==='angry'?.35:o.brow==='sad'?-.35:0;line([[-22,ey-16-b*8],[-7,ey-16+b*8]],DK,3);line([[7,ey-16+b*8],[22,ey-16-b*8]],DK,3)}
 if(o.glasses){c.save();c.strokeStyle=DK;c.lineWidth=2.5;c.beginPath();c.arc(-14,ey,12,0,7);c.moveTo(26,ey);c.arc(14,ey,12,0,7);c.moveTo(-2,ey);c.lineTo(2,ey);c.stroke();c.restore()}
 if(o.blush!==false)fill('rgba(240,110,130,.45)',()=>{ell(-24,ey+16,7,4);ell(24,ey+16,7,4)},0);
 if(window.EYESTYLE==='anime')line([[2,ey+13],[4,ey+16]],'rgba(60,30,30,.6)',2);else stk(skin,()=>ell(2,ey+12,5,6),1.6,0);
 const my=ey+26;
 if(mouth==='smile')line([[-12,my-2],[0,my+5],[12,my-2]],DK,3);
 if(mouth==='grin')stk('#fff',()=>{c.moveTo(-14,my-4);c.lineTo(14,my-4);c.quadraticCurveTo(0,my+14,-14,my-4)},2.2,0);
 if(mouth==='o')stk('#7a2a3a',()=>ell(0,my+4,9,13+Math.abs(Math.sin(t*12))*3),2.2,0);
 if(mouth==='cry'){stk('#7a2a3a',()=>{c.moveTo(-12,my+6);c.quadraticCurveTo(0,my-8,12,my+6);c.quadraticCurveTo(0,my+2,-12,my+6)},2,0);[-14,14].forEach((dx,k)=>{for(let i=0;i<4;i++){const p=((t*1.8+i/4+k*.5)%1);fill('#7fc8f0',()=>circ(dx+(k?1:-1)*(8+p*40),ey+8+p*60-Math.sin(p*Math.PI)*30,4.5-p*2),0)}})}
 if(mouth==='smirk')line([[-8,my],[4,my+2],[12,my-5]],DK,3);
 if(mouth==='flat')line([[-10,my+1],[10,my+1]],DK,3);
 if(o.stache)stk(hairC,()=>{ell(-8,my-6,10,4);ell(8,my-6,10,4)},1.5,0);
 if(o.sweat)stk('#9cd3f5',()=>{c.moveTo(40,hy-26);c.quadraticCurveTo(50,hy-12,40,hy-6);c.quadraticCurveTo(32,hy-12,40,hy-26)},1.6,3);
 c.restore()}
const MAE={hair:'long',hairC:'#2a1d24',top:'#f28fb1',bot:'#5a4a9a'};
const LOLA={hair:'bun',hairC:'#d8d8de',top:'#7fbf9a',bot:'#8a6a5a',glasses:true,skin:'#c99a6e',skirt:true};
const TITO={hair:'bald',hairC:'#3a2a24',top:'#f6f2e6',bot:'#3a3a4a',stache:true,skin:'#b97f52'};
const NENE={hair:'pony',hairC:'#3a2414',top:'#ffd166',bot:'#3a6fd8'};
const BOY={hair:'spiky',hairC:'#1d1a2e',top:'#2bb3a3',bot:'#2a2a44'};
const M=(a,b)=>Object.assign({},a,b);
/* ---- props ---- */
function tissueBox(x,y,s,n=1,t=0){c.save();c.translate(x,y);c.scale(s,s);if(n>0)stk('#ffffff',()=>{const h=20+n*46,sw=Math.sin(t*3)*6;c.moveTo(-22,-36);c.quadraticCurveTo(-30+sw,-36-h*.6,sw,-36-h);c.quadraticCurveTo(30+sw,-36-h*.6,22,-36)},2.2,5);
 stk('#7fc8e8',()=>rr(-60,-40,120,74,8),2.4,6);for(let i=0;i<4;i++)fill(i%2?'#f28fb1':'#fff6dc',()=>circ(-38+i*25,4,7),0);stk('#f6f2e6',()=>rr(-30,-46,60,12,6),1.8,3);
 c.font='700 15px Fredoka,sans-serif';c.fillStyle=DK;c.textAlign='center';c.fillText('TISSUE',0,26);c.restore()}
function phone(x,y,s,inner,rot=0){c.save();c.translate(x,y);c.rotate(rot);c.scale(s,s);stk('#2a2a38',()=>rr(-34,-62,68,124,12),2.4,6);c.save();c.beginPath();rr(-28,-52,56,100,6);c.clip();c.fillStyle='#e6f3ff';c.fillRect(-30,-54,60,104);inner&&inner();c.restore();c.restore()}
function heartS(x,y,s,col=PINK){stk(col,()=>{c.moveTo(x,y+10*s);c.bezierCurveTo(x-26*s,y-8*s,x-12*s,y-28*s,x,y-14*s);c.bezierCurveTo(x+12*s,y-28*s,x+26*s,y-8*s,x,y+10*s)},2.2,5)}
function sparkle(x,y,r,t){c.save();c.translate(x,y);c.rotate(t);fill('#fff8c8',()=>{for(let i=0;i<8;i++){const a=i/8*Math.PI*2,q=i%2?r*.3:r;c.lineTo(Math.cos(a)*q,Math.sin(a)*q)}},0);c.restore()}
function bub(x,y,w,h,s,size=30,col='#fffdf4',tail=1){stk(col,()=>{rr(x-w/2,y-h/2,w,h,18);c.moveTo(x-12*tail,y+h/2-2);c.lineTo(x-26*tail,y+h/2+24);c.lineTo(x+6*tail,y+h/2-2)},2.4,6);hand(s,x,y+size*.33,size,DK)}
function boom(x,y,r,txt2,k,col='#f4c430',tc='#e63946'){if(k<=0)return;at(x,y,k,()=>{stk(col,()=>{for(let i=0;i<18;i++){const a=i/18*Math.PI*2,q=i%2?r*.62:r;c.lineTo(Math.cos(a)*q*(1.2+txt2.length*.06),Math.sin(a)*q)}c.closePath()},3,8);c.font=`900 ${Math.min(r*.5,r*2.6/Math.max(3,txt2.length)*1.4)}px Fredoka,sans-serif`;c.fillStyle=tc;c.textAlign='center';c.fillText(txt2,0,r*.16);c.textAlign='left'})}
function crtTV(x,y,s,inner,on=1){c.save();c.translate(x,y);c.scale(s,s);patt('#c98a4a',()=>rr(-130,-100,260,190,22),2,'rgba(90,40,10,.18)',6);c.save();c.strokeStyle=DK;c.lineWidth=2.6;c.beginPath();rr(-130,-100,260,190,22);c.stroke();c.restore();
 c.save();c.beginPath();rr(-110,-82,180,150,26);c.clip();c.fillStyle='#1a1d22';c.fillRect(-112,-84,184,154);if(on>0){c.save();c.beginPath();c.ellipse(-20,-7,95*on,80*Math.max(.03,on*on),0,0,7);c.clip();c.fillStyle='#dff1f4';c.fillRect(-112,-84,184,154);inner&&inner(-20,-7);c.restore()}
 c.fillStyle='rgba(255,255,255,.08)';for(let yy=-84;yy<70;yy+=4)c.fillRect(-112,yy,184,1.5);c.restore();stk('#3a2a1c',()=>{circ(98,-50,10);circ(98,-12,10)},1.6,3);line([[-30,-100],[-70,-160]],DK,3);line([[0,-100],[40,-165]],DK,3);c.restore()}
function snow(t,n=60,near=false){for(let i=0;i<n;i++){const p=((t*(near?.09:.05)+hr(i*5))%1),x=(hr(i*7)*W+Math.sin(t*.8+i)*30)%W,y=-20+p*(H+40);c.save();c.globalAlpha=near?.95:.8;fill('#ffffff',()=>circ(x,y,(near?5:2)+hr(i)*3),0);c.restore()}}
function petals(t,n=26,col='#ffc4d6'){for(let i=0;i<n;i++){const p=((t*.06+hr(i))%1),x=(hr(i*3)*W+Math.sin(t+i)*60+p*200)%W,y=-30+p*(H+60);c.save();c.translate(x,y);c.rotate(t*1.5+i);fill(col,()=>{ell(0,0,9,5);ell(0,0,5,9)},1);c.restore()}}
function leafFall(t,n=14){for(let i=0;i<n;i++){const p=((t*.08+hr(i))%1);c.save();c.translate(hr(i*3)*W+Math.sin(t+i)*40,-20+p*(H+40));c.rotate(t+i);stk(['#e8743b','#c0262d','#f4c430'][i%3],()=>{c.moveTo(0,-14);c.quadraticCurveTo(12,0,0,14);c.quadraticCurveTo(-12,0,0,-14)},1.2,3);c.restore()}}
function rain(t,n=80){c.save();c.strokeStyle='rgba(200,225,255,.55)';c.lineWidth=2;for(let i=0;i<n;i++){const p=((t*1.2+hr(i))%1),x=(hr(i*3)*(W+200)-100+p*60),y=-40+p*(H+80);c.beginPath();c.moveTo(x,y);c.lineTo(x+10,y+30);c.stroke()}c.restore()}
function umbrella(x,y,s,col,t){c.save();c.translate(x,y);c.rotate(Math.sin(t*1.5+x)*.05);line([[0,-50*s],[0,110*s],[10*s,120*s]],DK,4);stk(col,()=>{c.moveTo(-90*s,0);c.quadraticCurveTo(0,-110*s,90*s,0);for(let i=0;i<4;i++)c.quadraticCurveTo(67*s-i*45*s,-18*s,45*s-i*45*s,0)},2.4,6);c.restore()}
function zzz(x,y,t){[0,1,2].forEach(i=>{const p=((t*.5+i/3)%1);c.save();c.globalAlpha=1-p;hand('z',x+p*40,y-p*70,22+p*16,'#fff6dc');c.restore()})}
function rooster(x,y,s,t,crow){c.save();c.translate(x,y);c.scale(s,s);stk('#c0262d',()=>{c.moveTo(-36,-10);c.quadraticCurveTo(-70,-50,-60,0);c.quadraticCurveTo(-50,10,-36,6)},2,4);stk('#f6f2e6',()=>ell(0,0,40,32),2.4,6);stk('#e63946',()=>{c.moveTo(18,-34);c.lineTo(24,-56);c.lineTo(32,-40);c.lineTo(40,-54);c.lineTo(42,-32);c.closePath()},2,4);stk('#f6f2e6',()=>ell(30,-26,18,18),2.2,5);stk('#f4c430',()=>{c.moveTo(46,-28);c.lineTo(crow?70:62,crow?-36:-24);c.lineTo(46,-20);c.closePath()},1.8,3);fill(DK,()=>circ(34,-30,3.5),0);c.restore()}
function eiffel(x,y,s){stk('#8a7a6a',()=>{c.moveTo(x-70*s,y);c.lineTo(x-8*s,y-260*s);c.lineTo(x+8*s,y-260*s);c.lineTo(x+70*s,y);c.lineTo(x+40*s,y);c.quadraticCurveTo(x,y-60*s,x-40*s,y);c.closePath()},2.4,6)}
function seoulTower(x,y,s,t){stk('#e8e4f0',()=>c.rect(x-8*s,y-300*s,16*s,300*s),2.2,5);stk('#f6f2e6',()=>rr(x-40*s,y-250*s,80*s,40*s,14*s),2.2,5);stk('#e63946',()=>c.rect(x-3*s,y-360*s,6*s,60*s),1.6,3);glow(x,y-360*s,40*s,'255,120,140',.5+.3*Math.sin(t*3))}
function lantern(x,y,s,col,t){const sw=Math.sin(t*1.6+x)*.08;c.save();c.translate(x,y);c.rotate(sw);line([[0,-60*s],[0,-30*s]],DK,2);stk(col,()=>ell(0,0,24*s,30*s),2.2,5);glow(0,0,70*s,'255,170,120',.35);c.restore()}
function stageCurtains(t,col='#6a5a9a',col2='#4a3e7a'){[[-80,1],[W+80,-1]].forEach(([x,f])=>{c.save();c.translate(x,0);c.scale(f,1);patt(col,()=>{c.moveTo(0,-60);c.lineTo(280+Math.sin(t*.8)*8,-60);c.quadraticCurveTo(200,300,260+Math.sin(t)*6,H+60);c.lineTo(0,H+60)},2,'rgba(0,0,0,.12)',10);for(let i=0;i<5;i++)line([[60+i*40,-60],[70+i*36,H+60]],col2,4);c.restore()});
 patt('#e63946',()=>{c.moveTo(-120,-60);c.lineTo(W+120,-60);c.lineTo(W+120,50);for(let i=0;i<10;i++)c.quadraticCurveTo(W+120-(i+.5)*(W+240)/10,110,W+120-(i+1)*(W+240)/10,50);c.closePath()},2,'rgba(0,0,0,.12)',8)}
function seats(t,col='#9a2a3a'){for(let i=0;i<8;i++){const x=-120+i*200;stk(col,()=>{c.moveTo(x,H+60);c.lineTo(x,H-40);c.quadraticCurveTo(x+85,H-110,x+170,H-40);c.lineTo(x+170,H+60)},2.6,10)}}
function bookshelf(x,y,w,h,seed){patt('#8a5a32',()=>c.rect(x,y,w,h),2,'rgba(40,20,5,.2)',8);for(let r=0;r<Math.floor(h/90);r++){let bx=x+10;while(bx<x+w-24){const bw=14+hr(seed+bx+r)*16,bh=50+hr(seed*2+bx)*28;stk(['#c0504d','#2bb3a3','#f4c430','#5a4a9a','#e8743b','#7fbf9a'][Math.floor(hr(bx*3+r+seed)*6)],()=>c.rect(bx,y+r*90+86-bh,bw,bh),1.2,0);bx+=bw+3}stk('#6a4024',()=>c.rect(x,y+r*90+86,w,8),1.2,0)}}
function archi(x,y,s,lit,t){const isl=[[-60,-180,40,90,.3],[-20,-60,50,40,0],[40,60,60,40,-.4],[100,170,70,50,0],[-80,120,30,50,0],[60,-110,26,40,.5]];isl.forEach(([dx,dy,rx,ry,r],i)=>news('#5aa36a',()=>ell(x+dx*s,y+dy*s,rx*s,ry*s,r),i+3,.12));
 for(let i=0;i<lit;i++){const k=i%isl.length,[dx,dy,rx,ry]=isl[k];fill(Math.sin(t*3+i)>-.5?'#ffe08a':'#fff3c0',()=>c.rect(x+(dx+(hr(i)-.5)*rx*1.2)*s,y+(dy+(hr(i*3)-.5)*ry*1.2)*s,7,8),0)}}
function sariStore(t){patt('#2bb3a3',()=>c.rect(170,150,940,420),0,'rgba(255,255,255,.25)',8);news('#f3d8a0',()=>c.rect(170,110,940,60),9,.25);hand('ALING NENA SARI-SARI STORE',640,152,40,'#e63946');
 stk('#8a5a32',()=>c.rect(200,190,880,40),1.8,0);c.save();c.strokeStyle='#8a5a32';c.lineWidth=5;for(let i=0;i<14;i++){c.beginPath();c.moveTo(220+i*62,230);c.lineTo(220+i*62,430);c.stroke()}c.restore();
 for(let i=0;i<12;i++){const sw=Math.sin(t*2+i)*4;stk(['#f28fb1','#f4c430','#7fbf9a','#e8743b'][i%4],()=>rr(230+i*70+sw,232,30,46,6),1.5,2)}
 patt('#c98a4a',()=>c.rect(170,430,940,140),2,'rgba(90,40,10,.18)',8);c.save();c.strokeStyle=DK;c.lineWidth=2.6;c.strokeRect(170,430,940,140);c.restore()}
function balconies(t,lit=1){patt('#4a4e78',()=>c.rect(40,40,1200,560),1,'rgba(255,255,255,.12)',8);for(let r=0;r<3;r++)for(let q=0;q<5;q++){const x=110+q*220,y=70+r*180;stk(lit&&Math.sin(t*1.5+r*3+q)>-.6?'#ffe9a8':'#8a90c0',()=>rr(x,y,150,110,8),2,0);if(lit)glow(x+75,y+55,110,'255,220,150',.18);stk('#2a2a44',()=>c.rect(x-10,y+110,170,10),1.8,0);for(let i=0;i<8;i++)line([[x-4+i*22,y+120],[x-4+i*22,y+150]],'#2a2a44',3);line([[x-10,y+150],[x+160,y+150]],'#2a2a44',4)}}
function barberPole(x,y,t){stk('#fff',()=>rr(x-16,y-100,32,200,16),2.4,6);c.save();c.beginPath();rr(x-16,y-100,32,200,16);c.clip();c.strokeStyle='#e63946';c.lineWidth=10;const o=(t*40)%40;for(let i=-6;i<8;i++){c.beginPath();c.moveTo(x-20,y-100+i*40+o);c.lineTo(x+20,y-80+i*40+o);c.stroke()}c.restore()}
function newsp(x,y,s,hole,t){c.save();c.translate(x,y);c.scale(s,s);news('#ece4d0',()=>rr(-100,-130,200,160,4),5,.3);c.save();c.strokeStyle=DK;c.lineWidth=2.4;c.strokeRect(-100,-130,200,160);c.restore();hand('DAILY BALITA',0,-104,26,DK);if(hole){fill('#1d140c',()=>circ(26,-50,20),0);stk('#fff',()=>ell(26,-50,13,15),1.6,0);fill(DK,()=>circ(26+Math.sin(t)*3,-48,6),0)}c.restore()}
function chartBoard(x,y,k,t){stk('#fffdf4',()=>rr(x-210,y-280,420,320,14),2.6,10);const hs=[60,70,80,clamp01(k)*600];hs.forEach((h,i)=>stk(i===3?'#e63946':'#9aa4c4',()=>c.rect(x-170+i*95,y-h,60,h),2.2,4));hand('2017  2018  2019  2020',x,y+30,26,DK)}
function paraglider(x,y,s,t){c.save();c.translate(x,y);c.rotate(Math.sin(t*1.5)*.1);stk('#f4c430',()=>{c.moveTo(-130*s,-90*s);c.quadraticCurveTo(0,-180*s,130*s,-90*s);c.quadraticCurveTo(0,-130*s,-130*s,-90*s)},2.4,6);c.strokeStyle=DK;c.lineWidth=1.5;c.beginPath();c.moveTo(-120*s,-92*s);c.lineTo(0,0);c.lineTo(120*s,-92*s);c.stroke();toon(0,128*s,.55*s,t,M(MAE,{top:'#fff',pose:'cheer',mouth:'o',pop:true}));c.restore()}
function crown(x,y,s){stk('#f4c430',()=>{c.moveTo(x-40*s,y);c.lineTo(x-46*s,y-50*s);c.lineTo(x-20*s,y-24*s);c.lineTo(x,y-60*s);c.lineTo(x+20*s,y-24*s);c.lineTo(x+46*s,y-50*s);c.lineTo(x+40*s,y);c.closePath()},2.6,6)}
function meter(x,y,v,t){stk('#fffdf4',()=>{c.arc(x,y,150,Math.PI,0);c.lineTo(x,y);c.closePath()},2.6,8);c.save();c.lineWidth=26;c.strokeStyle='#f28fb1';c.beginPath();c.arc(x,y,120,Math.PI,Math.PI+Math.PI*Math.min(1,v));c.stroke();c.restore();const a=Math.PI+Math.PI*Math.min(1.05,v)+(v>1?Math.sin(t*20)*.08:0);line([[x,y],[x+Math.cos(a)*110,y+Math.sin(a)*110]],DK,6);fill(DK,()=>circ(x,y,10),0)}
function calendarPage(x,y,label,rot){c.save();c.translate(x,y);c.rotate(rot);stk('#ffffff',()=>rr(-50,-60,100,120,8),2,5);fill('#e63946',()=>c.rect(-50,-60,100,28),0);hand(label,0,26,34,DK);c.restore()}
function filmStrip(x,y,n,k,w=58){for(let i=0;i<n;i++){const kk=clamp01(k*n-i);if(kk<=0)continue;at(x+i*(w+6),y,kk,()=>{stk('#2a2a38',()=>rr(-w/2,-36,w,72,6),2,4);fill('#dff1f4',()=>rr(-w/2+6,-26,w-12,52,4),0);hand(''+(i+1),0,10,24,DK)})}}
function bowl(x,y,col,lab){stk('#f6f2e6',()=>ell(x,y+10,56,20),2,4);stk(col,()=>ell(x,y,40,22),2,3);if(lab)hand(lab,x,y+56,26,DK)}
function laptopOn(x,y,inner){c.save();c.translate(x,y);stk('#3a3a48',()=>rr(-120,-150,240,140,10),2.4,6);c.save();c.beginPath();c.rect(-108,-140,216,120);c.clip();c.fillStyle='#dceeff';c.fillRect(-110,-142,220,124);inner&&inner();c.restore();stk('#55556a',()=>{c.moveTo(-140,0);c.lineTo(140,0);c.lineTo(120,-12);c.lineTo(-120,-12);c.closePath()},2.2,5);c.restore()}
function bedroom(t,dawn){const d=dawn;
 PL(t,.15,()=>{linedSky(d>.5?'#ffb88a':'#141a46',d>.5?'#ffe8b0':'#3a3f7e');if(d<=.5){fill('#fdf6d8',()=>circ(1080,120,46),0);glow(1080,120,160,'255,250,220',.3)}else{fill('#ffd27a',()=>circ(1010,420-d*260,56),0);glow(1010,420-d*260,260,'255,220,150',.5*d)}});
 PL(t,.3,()=>{for(let i=0;i<16;i++){const x=-160+i*100,h=160+hr(i)*240;news(d>.5?['#c88a9a','#b07a8a','#d89aa8'][i%3]:['#2c3266','#363c78','#262b5a'][i%3],()=>c.rect(x,H-200-h,86,h+40),i,.1);if(d<=.5)for(let k=0;k<6;k++)if(hr(i*7+k)>.45)fill(Math.sin(t+i+k)>-.7?'#ffe08a':'#3a3f7e',()=>c.rect(x+12+(k%2)*36,H-180-h+Math.floor(k/2)*44,18,22),0)}});
 PL(t,.7,()=>{c.save();c.beginPath();c.rect(-160,-80,W+320,H+160);c.rect(1220,40,-560,380);c.clip('evenodd');patt(d>.5?'#8a6a9a':'#3d2f5a',()=>c.rect(-160,-80,W+320,H+160),3,'rgba(255,255,255,.08)',0);c.restore();
  stk(d>.5?'#a88aba':'#5a4a7a',()=>{c.rect(650,30,580,14);c.rect(650,420,580,14);c.rect(930,40,12,380)},2,5);patt(d>.5?'#a07a8a':'#6a4a7a',()=>{c.moveTo(-160,540);c.lineTo(W+160,540);c.lineTo(W+160,H+80);c.lineTo(-160,H+80)},1,'rgba(255,255,255,.1)',4);
  stk('#e9e2f6',()=>rr(70,90,170,220,8),2,5);hand('K',155,230,120,'#c0504d');hand('poster',155,290,24,DK);if(d>.5)rays(1000,200,'255,230,180',6,800,.14*d,t)})}

/* v18: element visibility that carries across lines of the same place */
function vis(li,from,word,until=from){if(li<from)return 0;if(li===from)return word?(since(word)>=0?EASE(clamp01(since(word)/.8)):0):1;if(li<=until)return 1;if(li===until+1)return 1-EASE(clamp01(lt()/.7));return 0}
function withA(a,fn){if(a<=0)return;c.save();c.globalAlpha*=a;fn();c.restore()}
